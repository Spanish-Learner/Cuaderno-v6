// src/engine/studentModel.js
// The student model tracks everything about the learner

import { loadState, saveState } from "./storage";

const STUDENT_KEY = "cuaderno-student-v1";

// Grammar topics with confidence scores
export const GRAMMAR_TOPICS = {
  verb_conjugation: { label: "Verb Conjugation", score: 0, attempts: 0, correct: 0 },
  gender_agreement: { label: "Gender Agreement", score: 0, attempts: 0, correct: 0 },
  accents: { label: "Accents", score: 0, attempts: 0, correct: 0 },
  ser_vs_estar: { label: "Ser vs Estar", score: 0, attempts: 0, correct: 0 },
  preterite: { label: "Preterite Tense", score: 0, attempts: 0, correct: 0 },
  imperfect: { label: "Imperfect Tense", score: 0, attempts: 0, correct: 0 },
  future: { label: "Future Tense", score: 0, attempts: 0, correct: 0 },
  subjunctive: { label: "Subjunctive Mood", score: 0, attempts: 0, correct: 0 },
  prepositions: { label: "Prepositions", score: 0, attempts: 0, correct: 0 },
  pronouns: { label: "Pronouns", score: 0, attempts: 0, correct: 0 }
};

const DEFAULT_STUDENT = {
  level: "A1",
  xp: 0,
  streak: 0,
  accuracy: 100,
  totalCorrect: 0,
  totalAttempts: 0,
  knownWords: new Set(),
  weakWords: new Set(),
  mistakes: {
    verbs: {},
    accents: {},
    gender: {},
    vocabulary: {},
    punctuation: {},
    serEstar: {},
    prepositions: {}
  },
  confidence: JSON.parse(JSON.stringify(GRAMMAR_TOPICS)),
  conversationHistory: [],
  achievements: [],
  lastActive: null,
  sessionsCompleted: 0,
  wordsLearnedToday: 0
};

// ============================================================
// LOAD / SAVE
// ============================================================

export function loadStudent() {
  try {
    const saved = loadState();
    if (saved && saved.student) {
      // Convert Sets back from arrays
      const student = saved.student;
      student.knownWords = new Set(student.knownWords || []);
      student.weakWords = new Set(student.weakWords || []);
      return student;
    }
  } catch {}
  
  return JSON.parse(JSON.stringify(DEFAULT_STUDENT));
}

export function saveStudent(student) {
  const state = loadState();
  // Convert Sets to arrays for storage
  const exportable = {
    ...student,
    knownWords: Array.from(student.knownWords),
    weakWords: Array.from(student.weakWords)
  };
  saveState({ ...state, student: exportable });
}

export function updateStudent(update) {
  const student = loadStudent();
  const updated = { ...student, ...update };
  saveStudent(updated);
  return updated;
}

// ============================================================
// STATS
// ============================================================

export function getStudentStats(student) {
  const totalMistakes = Object.values(student.mistakes).reduce(
    (sum, category) => sum + Object.values(category).reduce((a, b) => a + b, 0),
    0
  );
  
  return {
    level: student.level,
    xp: student.xp,
    streak: student.streak,
    accuracy: student.accuracy,
    knownWords: student.knownWords.size,
    weakWords: student.weakWords.size,
    totalMistakes,
    sessionsCompleted: student.sessionsCompleted
  };
}

// ============================================================
// WORD TRACKING
// ============================================================

export function isWordKnown(student, word) {
  const lower = word.toLowerCase();
  return student.knownWords.has(lower);
}

export function markWordKnown(student, word) {
  const lower = word.toLowerCase();
  student.knownWords.add(lower);
  student.weakWords.delete(lower);
  saveStudent(student);
  return student;
}

export function markWordWeak(student, word) {
  const lower = word.toLowerCase();
  student.weakWords.add(lower);
  student.knownWords.delete(lower);
  saveStudent(student);
  return student;
}

// ============================================================
// MISTAKE TRACKING
// ============================================================

export function recordMistake(student, category, word) {
  if (!student.mistakes[category]) {
    student.mistakes[category] = {};
  }
  const lower = word.toLowerCase();
  student.mistakes[category][lower] = (student.mistakes[category][lower] || 0) + 1;
  saveStudent(student);
  return student;
}

// ============================================================
// ACCURACY
// ============================================================

export function updateAccuracy(student, correct) {
  student.totalAttempts = (student.totalAttempts || 0) + 1;
  if (correct) {
    student.totalCorrect = (student.totalCorrect || 0) + 1;
  }
  student.accuracy = Math.round((student.totalCorrect / student.totalAttempts) * 100);
  saveStudent(student);
  return student;
}

// ============================================================
// XP SYSTEM
// ============================================================

export function addXP(student, amount) {
  student.xp += amount;
  saveStudent(student);
  return student;
}

// ============================================================
// LEVEL UP
// ============================================================

export function checkLevelUp(student) {
  const xpRequired = {
    A1: 0,
    A2: 100,
    B1: 300,
    B2: 600,
    C1: 1000,
    C2: 1500
  };
  
  const levels = ["A1", "A2", "B1", "B2", "C1", "C2"];
  const currentIndex = levels.indexOf(student.level);
  
  for (let i = currentIndex + 1; i < levels.length; i++) {
    if (student.xp >= xpRequired[levels[i]]) {
      student.level = levels[i];
      return { leveledUp: true, newLevel: levels[i] };
    }
  }
  
  return { leveledUp: false };
}

// ============================================================
// CONFIDENCE SCORES
// ============================================================

export function updateConfidence(student, topic, correct) {
  if (!student.confidence) {
    student.confidence = JSON.parse(JSON.stringify(GRAMMAR_TOPICS));
  }
  
  const topicData = student.confidence[topic];
  if (topicData) {
    topicData.attempts++;
    if (correct) {
      topicData.correct++;
      topicData.score = Math.min(100, topicData.score + 5);
    } else {
      topicData.score = Math.max(0, topicData.score - 10);
    }
  }
  
  saveStudent(student);
  return student;
}

export function getConfidence(student, topic) {
  if (!student.confidence || !student.confidence[topic]) {
    return 0;
  }
  return student.confidence[topic].score;
}

export function getAllConfidence(student) {
  return student.confidence || GRAMMAR_TOPICS;
}