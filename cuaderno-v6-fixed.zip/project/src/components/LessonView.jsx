// src/components/LessonView.jsx
import React, { useState } from "react";

export default function LessonView({ lesson, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);

  if (!lesson) return null;

  const steps = [
    { type: "explanation", content: lesson.explanation },
    ...lesson.examples.map((ex, i) => ({ type: "example", content: ex, index: i })),
    ...lesson.practice.map((p, i) => ({ type: "practice", content: p, index: i })),
    { type: "quiz", questions: lesson.quiz },
    { type: "review", cards: lesson.review },
    { type: "complete" }
  ];

  const current = steps[currentStep];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowResults(true);
      if (onComplete) onComplete(lesson.id);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleAnswer = (questionIndex, answer) => {
    setAnswers((prev) => ({ ...prev, [questionIndex]: answer }));
  };

  const calculateQuizScore = () => {
    const quizQuestions = lesson.quiz || [];
    let correct = 0;
    quizQuestions.forEach((q, i) => {
      const key = lesson.practice.length + i;
      if (answers[key] === q.answer) correct++;
    });
    return `${correct}/${quizQuestions.length}`;
  };

  const renderStep = () => {
    switch (current.type) {
      case "explanation":
        return (
          <div className="lesson-explanation">
            <h3>📖 Explanation</h3>
            <div className="explanation-content">{current.content}</div>
          </div>
        );

      case "example":
        return (
          <div className="lesson-example">
            <h3>📝 Example {current.index + 1}</h3>
            <div className="example-card">
              <div className="example-es">{current.content.spanish}</div>
              <div className="example-en">{current.content.english}</div>
            </div>
          </div>
        );

      case "practice":
        return (
          <div className="lesson-practice">
            <h3>✍️ Practice {current.index + 1}</h3>
            <div className="practice-question">{current.content.question}</div>
            <input
              className="practice-input"
              placeholder="Type your answer..."
              value={answers[current.index] || ""}
              onChange={(e) => handleAnswer(current.index, e.target.value)}
            />
            <div className="practice-answer-hint">
              Hint: Think about the conjugation rule.
            </div>
          </div>
        );

      case "quiz":
        return (
          <div className="lesson-quiz">
            <h3>📝 Quiz</h3>
            {current.questions.map((q, i) => (
              <div key={i} className="quiz-question">
                <div className="quiz-question-text">{q.question}</div>
                <div className="quiz-options">
                  {q.options.map((opt, j) => (
                    <button
                      key={j}
                      className={`quiz-option ${answers[i] === opt ? "selected" : ""}`}
                      onClick={() => handleAnswer(i, opt)}
                    >
                      {String.fromCharCode(65 + j)}. {opt}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        );

      case "review":
        return (
          <div className="lesson-review">
            <h3>🃏 Review Flashcards</h3>
            <div className="review-cards">
              {current.cards.map((card, i) => (
                <div key={i} className="review-card">
                  <div className="review-front">{card.front}</div>
                  <div className="review-back">{card.back}</div>
                </div>
              ))}
            </div>
          </div>
        );

      case "complete":
        return (
          <div className="lesson-complete">
            <h3>🎉 Lesson Complete!</h3>
            <p>Great job! You've finished this lesson.</p>
            <div className="lesson-stats">
              <div>
                ✅ Practice questions:{" "}
                {Object.keys(answers).filter((k) => k < lesson.practice.length).length}{" "}
                answered
              </div>
              <div>📊 Quiz score: {calculateQuizScore()}</div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="lesson-view">
      <div className="lesson-header">
        <h2>{lesson.title}</h2>
        <div className="lesson-progress">
          Step {currentStep + 1} of {steps.length}
        </div>
      </div>

      <div className="lesson-content">{renderStep()}</div>

      <div className="lesson-controls">
        <button
          className="lesson-btn prev"
          onClick={handlePrevious}
          disabled={currentStep === 0}
        >
          ← Previous
        </button>
        <button
          className="lesson-btn next"
          onClick={handleNext}
        >
          {currentStep === steps.length - 1 ? "Finish 🎉" : "Next →"}
        </button>
      </div>
    </div>
  );
}