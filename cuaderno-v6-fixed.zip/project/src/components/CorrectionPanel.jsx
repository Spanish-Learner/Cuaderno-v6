// src/components/CorrectionPanel.jsx
import React, { useState } from "react";
import { explainCorrection } from "../engine/explainCorrection";

export default function CorrectionPanel({ correction }) {
  const [showExplanation, setShowExplanation] = useState(false);

  if (!correction) return null;

  const explanation = explainCorrection(
    correction.original,
    correction.corrected,
    correction.reasons
  );

  return (
    <div className="correction-panel">
      <h3>📝 Corrección</h3>

      <div className="correction-compare">
        <div className="correction-original">
          <strong>Original:</strong>
          <br />
          <span className="wrong">{correction.original}</span>
        </div>
        <div className="correction-arrow">→</div>
        <div className="correction-corrected">
          <strong>Correcto:</strong>
          <br />
          <span className="correct">{correction.corrected}</span>
        </div>
      </div>

      {correction.reasons.length > 0 && (
        <>
          <button
            className="why-btn"
            onClick={() => setShowExplanation(!showExplanation)}
          >
            {showExplanation ? "🔽 Ocultar explicación" : "❓ ¿Por qué?"}
          </button>

          {showExplanation && (
            <div className="correction-explanation">
              <h4>❓ ¿Por qué?</h4>
              <div className="explanation-text">{explanation.explanation}</div>

              {explanation.examples.length > 0 && (
                <div className="correction-examples">
                  <h4>📚 Ejemplos</h4>
                  {explanation.examples.map((ex, i) => (
                    <div key={i} className="example-item">
                      <div className="example-original">{ex.original}</div>
                      <div className="example-corrected">{ex.corrected}</div>
                    </div>
                  ))}
                </div>
              )}

              {explanation.practice && (
                <div className="correction-practice">
                  <h4>✍️ Practica</h4>
                  <div className="practice-question">{explanation.practice.question}</div>
                  <input
                    className="practice-input"
                    placeholder="Escribe tu respuesta..."
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        const answer = e.target.value.trim();
                        const isCorrect =
                          answer.toLowerCase() ===
                          explanation.practice.answer.toLowerCase();
                        alert(
                          isCorrect
                            ? "✅ ¡Correcto!"
                            : `❌ La respuesta correcta es: ${explanation.practice.answer}`
                        );
                        e.target.value = "";
                      }
                    }}
                  />
                  {explanation.practice.hint && (
                    <div className="practice-hint">💡 {explanation.practice.hint}</div>
                  )}
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}