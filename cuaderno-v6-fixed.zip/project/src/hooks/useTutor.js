// src/hooks/useTutor.js
import { useState, useEffect } from "react";
import { getTutorEngine } from "../engine/tutorEngine";
import { loadStudent } from "../engine/studentModel";

export default function useTutor() {
  const [engine, setEngine] = useState(null);
  const [student, setStudent] = useState(null);
  const [conversation, setConversation] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const tutor = getTutorEngine();
    setEngine(tutor);
    setStudent(loadStudent());
    setConversation(tutor.getConversationMemory());
    setStats(tutor.getStudentSnapshot());
    setLoading(false);
  }, []);

  const sendMessage = (message) => {
    if (!engine) return null;
    
    const result = engine.processInput(message);
    setStudent(result.student);
    setConversation(engine.getConversationMemory());
    setStats(result.student);
    
    return result;
  };

  const getPersonalizedLesson = () => {
    if (!engine) return null;
    return engine.generatePersonalizedLesson();
  };

  const getAchievements = () => {
    if (!student) return [];
    return student.achievements || [];
  };

  const getMistakeBreakdown = () => {
    if (!student) return {};
    return student.mistakes || {};
  };

  const resetProgress = () => {
    if (!engine) return;
    // Reset student progress
    const newStudent = loadStudent();
    // Clear known and weak words
    newStudent.knownWords = new Set();
    newStudent.weakWords = new Set();
    // Reset mistakes
    newStudent.mistakes = {
      verbs: {},
      accents: {},
      gender: {},
      vocabulary: {},
      punctuation: {},
      serEstar: {},
      prepositions: {}
    };
    // Reset stats
    newStudent.xp = 0;
    newStudent.accuracy = 100;
    newStudent.totalCorrect = 0;
    newStudent.totalAttempts = 0;
    newStudent.achievements = [];
    newStudent.sessionsCompleted = 0;
    
    setStudent(newStudent);
    setStats(newStudent);
    // Update engine's student
    engine.student = newStudent;
  };

  return {
    loading,
    student,
    conversation,
    stats,
    sendMessage,
    getPersonalizedLesson,
    getAchievements,
    getMistakeBreakdown,
    resetProgress,
    engine
  };
}