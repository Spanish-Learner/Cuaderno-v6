// src/hooks/useLessonGenerator.js
import { useState, useEffect } from "react";
import { generateAdaptiveLesson, generateContextLesson, generateLesson } from "../engine/lessonGenerator";
import { getTutorEngine } from "../engine/tutorEngine";

export default function useLessonGenerator() {
  const [lesson, setLesson] = useState(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const tutor = getTutorEngine();

  // Generate an adaptive lesson based on student profile
  const generateAdaptive = () => {
    setLoading(true);
    const newLesson = generateAdaptiveLesson();
    setLesson(newLesson);
    setHistory(prev => [...prev, { type: "adaptive", lesson: newLesson, timestamp: Date.now() }]);
    setLoading(false);
    return newLesson;
  };

  // Generate a context-aware lesson
  const generateContextual = (context) => {
    setLoading(true);
    const contextData = context || tutor.getConversationMemory();
    const newLesson = generateContextLesson(contextData);
    setLesson(newLesson);
    setHistory(prev => [...prev, { type: "contextual", lesson: newLesson, timestamp: Date.now() }]);
    setLoading(false);
    return newLesson;
  };

  // Generate a lesson on a specific topic
  const generateTopicLesson = (topic) => {
    setLoading(true);
    const newLesson = generateLesson(topic);
    setLesson(newLesson);
    setHistory(prev => [...prev, { type: "topic", topic, lesson: newLesson, timestamp: Date.now() }]);
    setLoading(false);
    return newLesson;
  };

  // Complete a lesson (mark as done)
  const completeLesson = (lessonId) => {
    // Track completion in student profile
    const student = tutor.student;
    student.sessionsCompleted = (student.sessionsCompleted || 0) + 1;
    // Add XP for completing a lesson
    tutor.addXP(20);
    // Store in history
    setHistory(prev => prev.map(h => 
      h.lesson.id === lessonId ? { ...h, completed: true, completedAt: Date.now() } : h
    ));
  };

  // Get lesson history
  const getHistory = () => history;

  // Clear history
  const clearHistory = () => setHistory([]);

  return {
    lesson,
    loading,
    history,
    generateAdaptive,
    generateContextual,
    generateTopicLesson,
    completeLesson,
    getHistory,
    clearHistory
  };
}