# Cuaderno — Offline Spanish Tutor

A fully offline Spanish learning app: chat practice with speech, the alphabet,
flashcard decks (preset + your own), and a three-way translator — all backed
by a built-in dictionary. No API keys, no server.

## What's actually offline vs. not

- **Text-to-speech (tutor speaking, letter sounds, flashcards):** fully offline —
  uses your device's own built-in voices.
- **Typing in Spanish, the dictionary, translator, flashcards, alphabet:** fully offline.
- **Speaking into the mic:** uses your browser/OS's built-in speech recognition.
  On most phones and Chrome, that recognition step itself briefly uses the
  browser's own recognition service — this is a browser limitation, not
  something this app controls. Typing always works with zero network use.

## Run it locally (to preview in a browser)

```bash
npm install
npm run dev
```

Then open the printed local address in your browser. Allow microphone access
if you want to try voice chat.

## Turn it into an Android APK using GitHub

You don't need Android Studio installed — GitHub's servers will build the APK for you.

1. Create a new **public or private repo** on GitHub.
2. Upload everything in this folder to that repo (drag-and-drop on github.com
   works, or use `git push` if you're comfortable with git).
3. Go to the **Actions** tab of your repo. A workflow called **"Build Android APK"**
   will run automatically (it's already set up in `.github/workflows/build-apk.yml`).
   - If it doesn't start automatically, click it, then click **"Run workflow"**.
4. Wait for the run to finish (a few minutes).
5. Click into the finished run → scroll to **Artifacts** → download
   **cuaderno-debug-apk**. Unzip it — that's your `.apk`.
6. Copy the `.apk` to your Android phone and open it to install. You'll need to
   allow "install unknown apps" for whichever app you used to open it (Files,
   Chrome, etc.) — this is standard for any app installed outside the Play Store.

That workflow uses [Capacitor](https://capacitorjs.com/) to wrap the web app
into a native Android project, then Gradle (Android's build tool) compiles it —
the same pipeline real Capacitor apps use, just running on GitHub's machines
instead of your own.

## Project structure

```
project/
├─ src/
│  ├─ App.jsx       ← the entire app (UI, dictionary, scenarios, styling)
│  └─ main.jsx       ← mounts App into the page
├─ index.html
├─ vite.config.js
├─ capacitor.config.json
├─ package.json
└─ .github/workflows/build-apk.yml   ← builds the APK automatically
```

## Extending the dictionary

All words live in the `BASE_DICTIONARY` array near the top of `src/App.jsx`.
Each entry looks like:

```js
{ es: "hola", en: "hello", ipa: "/ˈola/", pos: "interj", tags: ["greetings"] }
```

Add entries with a `tags` value matching an existing category (`food`, `travel`,
`greetings`, etc.) and they'll automatically show up in search and, if you add
a matching preset deck, in flashcards too.

## Your progress

Streak, words-learned count, and any custom decks you build are saved in the
browser's local storage on your device, so they'll still be there next time
you open the app on that same device/browser.
