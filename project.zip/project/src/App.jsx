// src/App.jsx
import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { loadState, saveState } from "./engine/storage";
import { correctSentence } from "./engine/grammar";
import { getLanguageEngine } from "./engine/databaseLoader";
import { getTutorEngine } from "./engine/tutorEngine";
import { getLearningGraphEngine } from "./engine/learningGraphEngine";
import { getReasoningEngine } from "./engine/reasoningEngine";
import useConversation from "./hooks/useConversation";
import useSmartDeck from "./hooks/useSmartDeck";
import useTutor from "./hooks/useTutor";
import useLessonGenerator from "./hooks/useLessonGenerator";
import useLearningGraph from "./hooks/useLearningGraph";
import useReasoning from "./hooks/useReasoning";
import CorrectionPanel from "./components/CorrectionPanel";
import LessonView from "./components/LessonView";
import { ALPHABET } from "./data/alphabet";
import { PRESET_DECKS } from "./data/decks";
import { DICTIONARY } from "./data/dictionary";
import { generateNumbersDeck } from "./data/numbers";
import { NUMBERS_DECK } from "./data/numbers";

const APP_VERSION = "6.0.0";

// ============================================================
// STORAGE
// ============================================================

const savedState = loadState();

// ============================================================
// MAIN APP
// ============================================================

export default function SpanishTutorApp() {
  const [tab, setTab] = useState(savedState.activeTab || "home");
  const [progress, setProgress] = useState(savedState.progress || {});
  const [settings, setSettings] = useState(savedState.settings || {});
  const [chatHistory, setChatHistory] = useState(savedState.chatHistory || []);
  const [translatorHistory, setTranslatorHistory] = useState(savedState.translatorHistory || []);
  const [learnedWords, setLearnedWords] = useState(savedState.learnedWords || {});
  const [corrections, setCorrections] = useState(savedState.corrections || []);
  const [lastCorrection, setLastCorrection] = useState(null);
  const [dbLoaded, setDbLoaded] = useState(false);

  // Load engines
  useEffect(() => {
    const languageEngine = getLanguageEngine();
    const tutorEngine = getTutorEngine();
    const graphEngine = getLearningGraphEngine();
    const reasoningEngine = getReasoningEngine();
    setDbLoaded(true);
  }, []);

  // Auto-save
  useEffect(() => {
    saveState({
      activeTab: tab,
      chatHistory,
      translatorHistory,
      progress,
      settings,
      learnedWords,
      corrections
    });
  }, [tab, chatHistory, translatorHistory, progress, settings, learnedWords, corrections]);

  // ============================================================
  // TABS
  // ============================================================

  const TABS = [
    { id: "home", label: "Home", icon: "🏠" },
    { id: "chat", label: "Chat", icon: "💬" },
    { id: "translate", label: "Translate", icon: "🌐" },
    { id: "flashcards", label: "Flashcards", icon: "🃏" },
    { id: "progress", label: "Progress", icon: "📊" }
  ];

  const activeIdx = TABS.findIndex((t) => t.id === tab);

  // ============================================================
  // RENDER
  // ============================================================

  if (!dbLoaded) {
    return (
      <div className="loading-screen">
        <div className="loading-spinner">🔄</div>
        <div className="loading-text">Cargando base de datos...</div>
      </div>
    );
  }

  return (
    <div className="app-root" onClickCapture={unlockSpeechIfNeeded}>
      <GlobalStyle />
      
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">ES</span>
          <div className="brand-text">
            <div className="brand-title">Cuaderno</div>
            <div className="brand-sub">your Spanish tutor · v{APP_VERSION}</div>
          </div>
        </div>
        <div className="stats">
          <div className="stamp">
            <div className="stamp-num">{progress.streak || 0}</div>
            <div className="stamp-label">day streak</div>
          </div>
          <div className="stamp teal">
            <div className="stamp-num">{Object.keys(learnedWords).length}</div>
            <div className="stamp-label">words learned</div>
          </div>
        </div>
      </header>

      <nav className="tabs">
        <div className="tab-indicator" style={{ transform: `translateX(${activeIdx * 100}%)`, width: `${100 / TABS.length}%` }} />
        {TABS.map((t) => (
          <button key={t.id} className={`tab-btn ${tab === t.id ? "active" : ""}`} onClick={() => setTab(t.id)}>
            <span className="tab-icon">{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </nav>

      <main className="content" key={tab}>
        {tab === "home" && <HomeTab />}
        {tab === "chat" && <ChatTab />}
        {tab === "translate" && <TranslateTab />}
        {tab === "flashcards" && <FlashcardsTab />}
        {tab === "progress" && <ProgressTab />}
      </main>
    </div>
  );
}

// ============================================================
// COMPONENT PLACEHOLDERS (to be implemented separately)
// ============================================================

function HomeTab() {
  return (
    <div className="home-tab">
      <h2>Bienvenido a Cuaderno</h2>
      <p>Your offline Spanish tutor.</p>
    </div>
  );
}

function ChatTab() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const recogRef = useRef(null);
  const logEndRef = useRef(null);

  const { send } = useConversation();
  const { correct, analysis } = useReasoning();

  const handleSend = (text) => {
    if (!text.trim()) return;
    unlockSpeechIfNeeded();

    // Analyze and correct
    const correction = correct(text);
    const reasoning = analysis(text);

    setMessages((m) => [...m, { from: "user", es: text }]);
    setLastCorrection(correction);

    // Generate bot response
    const botReply = send(text);

    setTimeout(() => {
      setMessages((m) => [...m, { from: "tutor", es: botReply }]);
    }, 400);

    setInput("");
  };

  return (
    <div className="chat-tab">
      <div className="chat-log">
        {messages.map((m, i) => (
          <div key={i} className={`bubble ${m.from}`}>
            {m.from === "tutor" && (
              <button className="speak-btn" onClick={() => speak(m.es)}>🔊</button>
            )}
            <div className="bubble-es">{m.es}</div>
            {m.en && <div className="bubble-en">{m.en}</div>}
          </div>
        ))}
        <div ref={logEndRef} />
      </div>

      {lastCorrection && <CorrectionPanel correction={lastCorrection} />}

      <div className="chat-input-row">
        <button className={`mic-btn ${listening ? "live" : ""}`} onClick={() => {}}>
          {listening ? "● listening" : "🎙️"}
        </button>
        <input
          className="chat-input"
          placeholder="Español…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend(input)}
        />
        <button className="send-btn" onClick={() => handleSend(input)}>Send</button>
      </div>
    </div>
  );
}

function TranslateTab() {
  return <div className="translate-tab">Translate tab coming soon.</div>;
}

function FlashcardsTab() {
  return <div className="flashcards-tab">Flashcards tab coming soon.</div>;
}

function ProgressTab() {
  return <div className="progress-tab">Progress tab coming soon.</div>;
}

// ============================================================
// STYLES
// ============================================================

function GlobalStyle() {
  return (
    <style>{`
      /* Copy your existing styles here, or import from a separate file */
    `}</style>
  );
}

// ============================================================
// SPEECH HELPERS
// ============================================================

let __speechUnlocked = false;

function unlockSpeechIfNeeded() {
  if (__speechUnlocked || !("speechSynthesis" in window)) return;
  __speechUnlocked = true;
  const u = new SpeechSynthesisUtterance(" ");
  u.volume = 0;
  window.speechSynthesis.speak(u);
}

function speak(text, lang = "es-ES") {
  if (!text || !("speechSynthesis" in window)) return;
  const synth = window.speechSynthesis;
  synth.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 0.9;
  u.lang = lang;
  synth.speak(u);
}