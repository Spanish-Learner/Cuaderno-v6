// src/data/adjectives.js

export const adjectivePairs = {
  alto: { masculine: "alto", feminine: "alta" },
  bajo: { masculine: "bajo", feminine: "baja" },
  bonito: { masculine: "bonito", feminine: "bonita" },
  feo: { masculine: "feo", feminine: "fea" },
  grande: { masculine: "grande", feminine: "grande" }, // Invariable
  pequeño: { masculine: "pequeño", feminine: "pequeña" },
  lindo: { masculine: "lindo", feminine: "linda" },
  guapo: { masculine: "guapo", feminine: "guapa" },
  inteligente: { masculine: "inteligente", feminine: "inteligente" }, // Invariable
  feliz: { masculine: "feliz", feminine: "feliz" }, // Invariable
  triste: { masculine: "triste", feminine: "triste" }, // Invariable
  cansado: { masculine: "cansado", feminine: "cansada" },
  ocupado: { masculine: "ocupado", feminine: "ocupada" },
  aburrido: { masculine: "aburrido", feminine: "aburrida" },
  contento: { masculine: "contento", feminine: "contenta" },
  enojado: { masculine: "enojado", feminine: "enojada" },
  preocupado: { masculine: "preocupado", feminine: "preocupada" },
  rojo: { masculine: "rojo", feminine: "roja" },
  azul: { masculine: "azul", feminine: "azul" }, // Invariable
  verde: { masculine: "verde", feminine: "verde" }, // Invariable
  amarillo: { masculine: "amarillo", feminine: "amarilla" },
  blanco: { masculine: "blanco", feminine: "blanca" },
  negro: { masculine: "negro", feminine: "negra" },
  morado: { masculine: "morado", feminine: "morada" },
  rosa: { masculine: "rosa", feminine: "rosa" }, // Invariable
  gris: { masculine: "gris", feminine: "gris" }, // Invariable
  marrón: { masculine: "marrón", feminine: "marrón" }, // Invariable
  nuevo: { masculine: "nuevo", feminine: "nueva" },
  viejo: { masculine: "viejo", feminine: "vieja" },
  rápido: { masculine: "rápido", feminine: "rápida" },
  lento: { masculine: "lento", feminine: "lenta" },
  caro: { masculine: "caro", feminine: "cara" },
  barato: { masculine: "barato", feminine: "barata" },
  sucio: { masculine: "sucio", feminine: "sucia" },
  limpio: { masculine: "limpio", feminine: "limpia" },
  lleno: { masculine: "lleno", feminine: "llena" },
  vacío: { masculine: "vacío", feminine: "vacía" },
  importante: { masculine: "importante", feminine: "importante" }, // Invariable
  difícil: { masculine: "difícil", feminine: "difícil" }, // Invariable
  fácil: { masculine: "fácil", feminine: "fácil" }, // Invariable
  posible: { masculine: "posible", feminine: "posible" }, // Invariable
  imposible: { masculine: "imposible", feminine: "imposible" }, // Invariable
  joven: { masculine: "joven", feminine: "joven" }, // Invariable
  amable: { masculine: "amable", feminine: "amable" }, // Invariable
  fuerte: { masculine: "fuerte", feminine: "fuerte" }, // Invariable
  débil: { masculine: "débil", feminine: "débil" } // Invariable
};

// Adjectives that don't change with gender
export const invariableAdjectives = [
  "grande", "inteligente", "feliz", "triste", "azul", "verde",
  "rosa", "gris", "marrón", "importante", "difícil", "fácil",
  "posible", "imposible", "joven", "amable", "fuerte", "débil"
];

export function getAdjectiveForm(adj, gender, number) {
  const lower = adj.toLowerCase();

  // Check if adjective is invariable
  if (invariableAdjectives.includes(lower)) {
    return number === "plural" ? `${lower}s` : lower;
  }

  // Check if in our pairs
  const pair = adjectivePairs[lower];
  if (pair) {
    const genderForm = gender === "feminine" ? pair.feminine : pair.masculine;
    return number === "plural" ? `${genderForm}s` : genderForm;
  }

  // Fallback: add -s for plural
  return number === "plural" ? `${lower}s` : lower;
}