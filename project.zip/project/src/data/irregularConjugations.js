// src/data/irregularConjugations.js

// Store irregular verbs explicitly — all tenses, all forms
export const IRREGULAR_VERBS = {
  ir: {
    infinitive: "ir",
    type: "ir",
    present: ["voy", "vas", "va", "vamos", "vais", "van"],
    preterite: ["fui", "fuiste", "fue", "fuimos", "fuisteis", "fueron"],
    imperfect: ["iba", "ibas", "iba", "íbamos", "ibais", "iban"],
    future: ["iré", "irás", "irá", "iremos", "iréis", "irán"],
    conditional: ["iría", "irías", "iría", "iríamos", "iríais", "irían"],
    presentPerfect: ["ido"],
    imperative: ["ve", "id"],
    presentSubjunctive: ["vaya", "vayas", "vaya", "vayamos", "vayáis", "vayan"]
  },
  ser: {
    infinitive: "ser",
    type: "er",
    present: ["soy", "eres", "es", "somos", "sois", "son"],
    preterite: ["fui", "fuiste", "fue", "fuimos", "fuisteis", "fueron"],
    imperfect: ["era", "eras", "era", "éramos", "erais", "eran"],
    future: ["seré", "serás", "será", "seremos", "seréis", "serán"],
    conditional: ["sería", "serías", "sería", "seríamos", "seríais", "serían"],
    presentPerfect: ["sido"],
    imperative: ["sé", "sed"],
    presentSubjunctive: ["sea", "seas", "sea", "seamos", "seáis", "sean"]
  },
  estar: {
    infinitive: "estar",
    type: "ar",
    present: ["estoy", "estás", "está", "estamos", "estáis", "están"],
    preterite: ["estuve", "estuviste", "estuvo", "estuvimos", "estuvisteis", "estuvieron"],
    imperfect: ["estaba", "estabas", "estaba", "estábamos", "estabais", "estaban"],
    future: ["estaré", "estarás", "estará", "estaremos", "estaréis", "estarán"],
    conditional: ["estaría", "estarías", "estaría", "estaríamos", "estaríais", "estarían"],
    presentPerfect: ["estado"],
    imperative: ["está", "estad"],
    presentSubjunctive: ["esté", "estés", "esté", "estemos", "estéis", "estén"]
  },
  tener: {
    infinitive: "tener",
    type: "er",
    present: ["tengo", "tienes", "tiene", "tenemos", "tenéis", "tienen"],
    preterite: ["tuve", "tuviste", "tuvo", "tuvimos", "tuvisteis", "tuvieron"],
    imperfect: ["tenía", "tenías", "tenía", "teníamos", "teníais", "tenían"],
    future: ["tendré", "tendrás", "tendrá", "tendremos", "tendréis", "tendrán"],
    conditional: ["tendría", "tendrías", "tendría", "tendríamos", "tendríais", "tendrían"],
    presentPerfect: ["tenido"],
    imperative: ["ten", "tened"],
    presentSubjunctive: ["tenga", "tengas", "tenga", "tengamos", "tengáis", "tengan"]
  },
  hacer: {
    infinitive: "hacer",
    type: "er",
    present: ["hago", "haces", "hace", "hacemos", "hacéis", "hacen"],
    preterite: ["hice", "hiciste", "hizo", "hicimos", "hicisteis", "hicieron"],
    imperfect: ["hacía", "hacías", "hacía", "hacíamos", "hacíais", "hacían"],
    future: ["haré", "harás", "hará", "haremos", "haréis", "harán"],
    conditional: ["haría", "harías", "haría", "haríamos", "haríais", "harían"],
    presentPerfect: ["hecho"],
    imperative: ["haz", "haced"],
    presentSubjunctive: ["haga", "hagas", "haga", "hagamos", "hagáis", "hagan"]
  },
  decir: {
    infinitive: "decir",
    type: "ir",
    present: ["digo", "dices", "dice", "decimos", "decís", "dicen"],
    preterite: ["dije", "dijiste", "dijo", "dijimos", "dijisteis", "dijeron"],
    imperfect: ["decía", "decías", "decía", "decíamos", "decíais", "decían"],
    future: ["diré", "dirás", "dirá", "diremos", "diréis", "dirán"],
    conditional: ["diría", "dirías", "diría", "diríamos", "diríais", "dirían"],
    presentPerfect: ["dicho"],
    imperative: ["di", "decid"],
    presentSubjunctive: ["diga", "digas", "diga", "digamos", "digáis", "digan"]
  },
  venir: {
    infinitive: "venir",
    type: "ir",
    present: ["vengo", "vienes", "viene", "venimos", "venís", "vienen"],
    preterite: ["vine", "viniste", "vino", "vinimos", "vinisteis", "vinieron"],
    imperfect: ["venía", "venías", "venía", "veníamos", "veníais", "venían"],
    future: ["vendré", "vendrás", "vendrá", "vendremos", "vendréis", "vendrán"],
    conditional: ["vendría", "vendrías", "vendría", "vendríamos", "vendríais", "vendrían"],
    presentPerfect: ["venido"],
    imperative: ["ven", "venid"],
    presentSubjunctive: ["venga", "vengas", "venga", "vengamos", "vengáis", "vengan"]
  },
  poder: {
    infinitive: "poder",
    type: "er",
    present: ["puedo", "puedes", "puede", "podemos", "podéis", "pueden"],
    preterite: ["pude", "pudiste", "pudo", "pudimos", "pudisteis", "pudieron"],
    imperfect: ["podía", "podías", "podía", "podíamos", "podíais", "podían"],
    future: ["podré", "podrás", "podrá", "podremos", "podréis", "podrán"],
    conditional: ["podría", "podrías", "podría", "podríamos", "podríais", "podrían"],
    presentPerfect: ["podido"],
    imperative: ["puede", "poded"],
    presentSubjunctive: ["pueda", "puedas", "pueda", "podamos", "podáis", "puedan"]
  },
  poner: {
    infinitive: "poner",
    type: "er",
    present: ["pongo", "pones", "pone", "ponemos", "ponéis", "ponen"],
    preterite: ["puse", "pusiste", "puso", "pusimos", "pusisteis", "pusieron"],
    imperfect: ["ponía", "ponías", "ponía", "poníamos", "poníais", "ponían"],
    future: ["pondré", "pondrás", "pondrá", "pondremos", "pondréis", "pondrán"],
    conditional: ["pondría", "pondrías", "pondría", "pondríamos", "pondríais", "pondrían"],
    presentPerfect: ["puesto"],
    imperative: ["pon", "poned"],
    presentSubjunctive: ["ponga", "pongas", "ponga", "pongamos", "pongáis", "pongan"]
  },
  querer: {
    infinitive: "querer",
    type: "er",
    present: ["quiero", "quieres", "quiere", "queremos", "queréis", "quieren"],
    preterite: ["quise", "quisiste", "quiso", "quisimos", "quisisteis", "quisieron"],
    imperfect: ["quería", "querías", "quería", "queríamos", "queríais", "querían"],
    future: ["querré", "querrás", "querrá", "querremos", "querréis", "querrán"],
    conditional: ["querría", "querrías", "querría", "querríamos", "querríais", "querrían"],
    presentPerfect: ["querido"],
    imperative: ["quiere", "quered"],
    presentSubjunctive: ["quiera", "quieras", "quiera", "queramos", "queráis", "quieran"]
  },
  saber: {
    infinitive: "saber",
    type: "er",
    present: ["sé", "sabes", "sabe", "sabemos", "sabéis", "saben"],
    preterite: ["supe", "supiste", "supo", "supimos", "supisteis", "supieron"],
    imperfect: ["sabía", "sabías", "sabía", "sabíamos", "sabíais", "sabían"],
    future: ["sabré", "sabrás", "sabrá", "sabremos", "sabréis", "sabrán"],
    conditional: ["sabría", "sabrías", "sabría", "sabríamos", "sabríais", "sabrían"],
    presentPerfect: ["sabido"],
    imperative: ["sabe", "sabed"],
    presentSubjunctive: ["sepa", "sepas", "sepa", "sepamos", "sepáis", "sepan"]
  },
  haber: {
    infinitive: "haber",
    type: "er",
    present: ["he", "has", "ha", "hemos", "habéis", "han"],
    preterite: ["hube", "hubiste", "hubo", "hubimos", "hubisteis", "hubieron"],
    imperfect: ["había", "habías", "había", "habíamos", "habíais", "habían"],
    future: ["habré", "habrás", "habrá", "habremos", "habréis", "habrán"],
    conditional: ["habría", "habrías", "habría", "habríamos", "habríais", "habrían"],
    presentPerfect: ["habido"],
    imperative: ["he", "habed"],
    presentSubjunctive: ["haya", "hayas", "haya", "hayamos", "hayáis", "hayan"]
  },
  salir: {
    infinitive: "salir",
    type: "ir",
    present: ["salgo", "sales", "sale", "salimos", "salís", "salen"],
    preterite: ["salí", "saliste", "salió", "salimos", "salisteis", "salieron"],
    imperfect: ["salía", "salías", "salía", "salíamos", "salíais", "salían"],
    future: ["saldré", "saldrás", "saldrá", "saldremos", "saldréis", "saldrán"],
    conditional: ["saldría", "saldrías", "saldría", "saldríamos", "saldríais", "saldrían"],
    presentPerfect: ["salido"],
    imperative: ["sal", "salid"],
    presentSubjunctive: ["salga", "salgas", "salga", "salgamos", "salgáis", "salgan"]
  },
  dar: {
    infinitive: "dar",
    type: "ar",
    present: ["doy", "das", "da", "damos", "dais", "dan"],
    preterite: ["di", "diste", "dio", "dimos", "disteis", "dieron"],
    imperfect: ["daba", "dabas", "daba", "dábamos", "dabais", "daban"],
    future: ["daré", "darás", "dará", "daremos", "daréis", "darán"],
    conditional: ["daría", "darías", "daría", "daríamos", "daríais", "darían"],
    presentPerfect: ["dado"],
    imperative: ["da", "dad"],
    presentSubjunctive: ["dé", "des", "dé", "demos", "déis", "den"]
  },
  ver: {
    infinitive: "ver",
    type: "er",
    present: ["veo", "ves", "ve", "vemos", "veis", "ven"],
    preterite: ["vi", "viste", "vio", "vimos", "visteis", "vieron"],
    imperfect: ["veía", "veías", "veía", "veíamos", "veíais", "veían"],
    future: ["veré", "verás", "verá", "veremos", "veréis", "verán"],
    conditional: ["vería", "verías", "vería", "veríamos", "veríais", "verían"],
    presentPerfect: ["visto"],
    imperative: ["ve", "ved"],
    presentSubjunctive: ["vea", "veas", "vea", "veamos", "veáis", "vean"]
  },
  traer: {
    infinitive: "traer",
    type: "er",
    present: ["traigo", "traes", "trae", "traemos", "traéis", "traen"],
    preterite: ["traje", "trajiste", "trajo", "trajimos", "trajisteis", "trajeron"],
    imperfect: ["traía", "traías", "traía", "traíamos", "traíais", "traían"],
    future: ["traeré", "traerás", "traerá", "traeremos", "traeréis", "traerán"],
    conditional: ["traería", "traerías", "traería", "traeríamos", "traeríais", "traerían"],
    presentPerfect: ["traído"],
    imperative: ["trae", "traed"],
    presentSubjunctive: ["traiga", "traigas", "traiga", "traigamos", "traigáis", "traigan"]
  }
};

// Export the irregular verbs list for indexing
export const IRREGULAR_VERB_LIST = Object.values(IRREGULAR_VERBS);

// Build a quick lookup map for irregular verbs by infinitive
export const irregularMap = IRREGULAR_VERBS;

// Check if a verb is irregular
export function isIrregular(verb) {
  return !!IRREGULAR_VERBS[verb];
}

// Get irregular forms for a verb
export function getIrregularForms(verb, tense) {
  const entry = IRREGULAR_VERBS[verb];
  if (!entry || !entry[tense]) {
    return null;
  }
  return entry[tense];
}