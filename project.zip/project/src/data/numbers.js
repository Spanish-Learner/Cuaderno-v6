// src/data/numbers.js

const ONES = [
  "cero", "uno", "dos", "tres", "cuatro", "cinco",
  "seis", "siete", "ocho", "nueve"
];

const TEENS = {
  10: "diez", 11: "once", 12: "doce", 13: "trece",
  14: "catorce", 15: "quince", 16: "dieciséis",
  17: "diecisiete", 18: "dieciocho", 19: "diecinueve"
};

const TENS = {
  20: "veinte", 30: "treinta", 40: "cuarenta",
  50: "cincuenta", 60: "sesenta", 70: "setenta",
  80: "ochenta", 90: "noventa", 100: "cien"
};

function spanishNumber(n) {
  if (n < 10) return ONES[n];
  if (TEENS[n]) return TEENS[n];
  if (n === 20) return "veinte";
  if (n < 30) return "veinti" + ONES[n - 20];
  if (n === 100) return "cien";

  const ten = Math.floor(n / 10) * 10;
  const one = n % 10;
  if (one === 0) return TENS[ten];
  return `${TENS[ten]} y ${ONES[one]}`;
}

export function generateNumbersDeck() {
  const deck = [];
  for (let i = 0; i <= 100; i++) {
    deck.push({
      id: `num_${i}`,
      category: "Numbers",
      front: String(i),
      back: spanishNumber(i),
      english: String(i),
      mastered: false,
      favorite: false,
      difficulty: i <= 20 ? 1 : i <= 50 ? 2 : 3,
      lastReviewed: null,
      reviewCount: 0,
      nextReview: null,
      streak: 0,
      maxStreak: 0,
      misses: 0
    });
  }
  return deck;
}

export const NUMBERS_DECK = generateNumbersDeck();