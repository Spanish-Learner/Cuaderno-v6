// src/data/learningGraph.js
// The Learning Graph connects words, grammar concepts, and topics

export const LEARNING_GRAPH = {
  // === VERB NODES ===
  comer: {
    id: "comer",
    type: "verb",
    label: "comer (to eat)",
    connectsTo: ["comida", "hambre", "beber", "restaurante", "cocina", "desayuno", "almuerzo", "cena"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 1,
    category: "food"
  },
  hablar: {
    id: "hablar",
    type: "verb",
    label: "hablar (to speak)",
    connectsTo: ["conversación", "idioma", "palabra", "lengua"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 1,
    category: "communication"
  },
  ir: {
    id: "ir",
    type: "verb",
    label: "ir (to go)",
    connectsTo: ["viaje", "destino", "camino", "llegada"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 2,
    category: "travel"
  },
  ser: {
    id: "ser",
    type: "verb",
    label: "ser (to be - permanent)",
    connectsTo: ["esencia", "identidad", "origen", "profesión"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 2,
    category: "core"
  },
  estar: {
    id: "estar",
    type: "verb",
    label: "estar (to be - temporary)",
    connectsTo: ["ubicación", "estado", "emoción", "condición"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 2,
    category: "core"
  },
  tener: {
    id: "tener",
    type: "verb",
    label: "tener (to have)",
    connectsTo: ["posesión", "edad", "hambre", "sed", "suerte"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 1,
    category: "core"
  },
  hacer: {
    id: "hacer",
    type: "verb",
    label: "hacer (to do/make)",
    connectsTo: ["actividad", "tarea", "acción", "creación"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 2,
    category: "core"
  },
  decir: {
    id: "decir",
    type: "verb",
    label: "decir (to say/tell)",
    connectsTo: ["palabra", "mensaje", "opinión", "verdad"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 2,
    category: "communication"
  },
  poder: {
    id: "poder",
    type: "verb",
    label: "poder (to be able to)",
    connectsTo: ["capacidad", "oportunidad", "permiso"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 2,
    category: "core"
  },
  querer: {
    id: "querer",
    type: "verb",
    label: "querer (to want)",
    connectsTo: ["deseo", "intención", "preferencia"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 2,
    category: "core"
  },
  saber: {
    id: "saber",
    type: "verb",
    label: "saber (to know)",
    connectsTo: ["conocimiento", "información", "hecho"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 2,
    category: "core"
  },
  vivir: {
    id: "vivir",
    type: "verb",
    label: "vivir (to live)",
    connectsTo: ["vida", "hogar", "experiencia", "ciudad"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 1,
    category: "daily"
  },
  trabajar: {
    id: "trabajar",
    type: "verb",
    label: "trabajar (to work)",
    connectsTo: ["trabajo", "oficina", "empleo", "profesión"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 1,
    category: "work"
  },
  estudiar: {
    id: "estudiar",
    type: "verb",
    label: "estudiar (to study)",
    connectsTo: ["estudio", "escuela", "universidad", "aprendizaje"],
    grammarConnections: ["present", "preterite", "imperfect", "future"],
    difficulty: 1,
    category: "education"
  },

  // === NOUN NODES ===
  comida: {
    id: "comida",
    type: "noun",
    label: "comida (food)",
    connectsTo: ["comer", "hambre", "cocina", "restaurante", "almuerzo", "cena", "desayuno"],
    difficulty: 1,
    category: "food"
  },
  hambre: {
    id: "hambre",
    type: "noun",
    label: "hambre (hunger)",
    connectsTo: ["comer", "comida", "tener hambre"],
    difficulty: 1,
    category: "food"
  },
  restaurante: {
    id: "restaurante",
    type: "noun",
    label: "restaurante (restaurant)",
    connectsTo: ["comer", "comida", "menú", "cena"],
    difficulty: 1,
    category: "food"
  },
  cocina: {
    id: "cocina",
    type: "noun",
    label: "cocina (kitchen)",
    connectsTo: ["comer", "comida", "cocinar"],
    difficulty: 1,
    category: "food"
  },
  desayuno: {
    id: "desayuno",
    type: "noun",
    label: "desayuno (breakfast)",
    connectsTo: ["comer", "comida", "mañana"],
    difficulty: 1,
    category: "food"
  },
  almuerzo: {
    id: "almuerzo",
    type: "noun",
    label: "almuerzo (lunch)",
    connectsTo: ["comer", "comida", "mediodía"],
    difficulty: 1,
    category: "food"
  },
  cena: {
    id: "cena",
    type: "noun",
    label: "cena (dinner)",
    connectsTo: ["comer", "comida", "noche"],
    difficulty: 1,
    category: "food"
  },
  beber: {
    id: "beber",
    type: "verb",
    label: "beber (to drink)",
    connectsTo: ["agua", "bebida", "comer", "hambre"],
    difficulty: 1,
    category: "food"
  },
  agua: {
    id: "agua",
    type: "noun",
    label: "agua (water)",
    connectsTo: ["beber", "vida", "sed"],
    difficulty: 1,
    category: "food"
  },
  
  // === GRAMMAR NODES ===
  present: {
    id: "present",
    type: "grammar",
    label: "Present Tense",
    connectsTo: ["preterite", "imperfect", "future"],
    difficulty: 1,
    category: "grammar"
  },
  preterite: {
    id: "preterite",
    type: "grammar",
    label: "Preterite Tense",
    connectsTo: ["present", "imperfect", "future"],
    difficulty: 2,
    category: "grammar"
  },
  imperfect: {
    id: "imperfect",
    type: "grammar",
    label: "Imperfect Tense",
    connectsTo: ["present", "preterite", "future"],
    difficulty: 2,
    category: "grammar"
  },
  future: {
    id: "future",
    type: "grammar",
    label: "Future Tense",
    connectsTo: ["present", "preterite", "imperfect"],
    difficulty: 2,
    category: "grammar"
  },
  "ser vs estar": {
    id: "ser vs estar",
    type: "grammar",
    label: "Ser vs Estar",
    connectsTo: ["ser", "estar"],
    difficulty: 3,
    category: "grammar"
  },
  "gender agreement": {
    id: "gender agreement",
    type: "grammar",
    label: "Gender Agreement",
    connectsTo: ["nouns", "adjectives"],
    difficulty: 2,
    category: "grammar"
  },
  "subjunctive": {
    id: "subjunctive",
    type: "grammar",
    label: "Subjunctive Mood",
    connectsTo: ["present", "imperfect"],
    difficulty: 4,
    category: "grammar"
  },

  // === EXPRESSION NODES ===
  "tener hambre": {
    id: "tener hambre",
    type: "expression",
    label: "tener hambre (to be hungry)",
    connectsTo: ["comer", "hambre", "comida"],
    difficulty: 1,
    category: "food"
  },
  "hacer frío": {
    id: "hacer frío",
    type: "expression",
    label: "hacer frío (to be cold - weather)",
    connectsTo: ["clima", "invierno", "frío"],
    difficulty: 1,
    category: "weather"
  },
  "hacer calor": {
    id: "hacer calor",
    type: "expression",
    label: "hacer calor (to be hot - weather)",
    connectsTo: ["clima", "verano", "calor"],
    difficulty: 1,
    category: "weather"
  },
  "tener sed": {
    id: "tener sed",
    type: "expression",
    label: "tener sed (to be thirsty)",
    connectsTo: ["beber", "agua", "sed"],
    difficulty: 1,
    category: "food"
  },

  // === TOPIC NODES ===
  food: {
    id: "food",
    type: "topic",
    label: "Food & Drink",
    connectsTo: ["comer", "comida", "hambre", "beber", "agua", "restaurante", "cocina"],
    difficulty: 1,
    category: "daily"
  },
  travel: {
    id: "travel",
    type: "topic",
    label: "Travel & Places",
    connectsTo: ["ir", "viaje", "ciudad", "país", "hotel", "aeropuerto"],
    difficulty: 2,
    category: "travel"
  },
  family: {
    id: "family",
    type: "topic",
    label: "Family & People",
    connectsTo: ["familia", "madre", "padre", "hermano", "hijo"],
    difficulty: 1,
    category: "people"
  },
  education: {
    id: "education",
    type: "topic",
    label: "Education & Learning",
    connectsTo: ["estudiar", "escuela", "universidad", "aprender", "libro"],
    difficulty: 1,
    category: "education"
  },
  work: {
    id: "work",
    type: "topic",
    label: "Work & Career",
    connectsTo: ["trabajar", "trabajo", "oficina", "empleo", "profesión"],
    difficulty: 1,
    category: "work"
  },
  core: {
    id: "core",
    type: "topic",
    label: "Core Vocabulary",
    connectsTo: ["ser", "estar", "tener", "hacer", "decir", "poder", "querer", "saber"],
    difficulty: 1,
    category: "core"
  }
};

// ============================================================
// GRAPH HELPERS
// ============================================================

export function getNode(id) {
  return LEARNING_GRAPH[id] || null;
}

export function getConnections(id) {
  const node = getNode(id);
  return node ? node.connectsTo : [];
}

export function getRelatedNodes(id, maxDepth = 1) {
  const visited = new Set();
  const results = [];
  
  function traverse(currentId, depth) {
    if (depth > maxDepth || visited.has(currentId)) return;
    visited.add(currentId);
    
    const node = getNode(currentId);
    if (node && currentId !== id) {
      results.push(node);
    }
    
    if (depth < maxDepth && node) {
      for (const connection of node.connectsTo || []) {
        traverse(connection, depth + 1);
      }
    }
  }
  
  traverse(id, 0);
  return results;
}

export function getPathBetween(start, end) {
  // Simple BFS to find a path between two nodes
  const queue = [[start]];
  const visited = new Set([start]);
  
  while (queue.length > 0) {
    const path = queue.shift();
    const last = path[path.length - 1];
    
    if (last === end) {
      return path;
    }
    
    const connections = getConnections(last);
    for (const conn of connections) {
      if (!visited.has(conn)) {
        visited.add(conn);
        queue.push([...path, conn]);
      }
    }
  }
  
  return null; // No path found
}

export function getRelatedByCategory(category) {
  const results = [];
  for (const [id, node] of Object.entries(LEARNING_GRAPH)) {
    if (node.category === category) {
      results.push(node);
    }
  }
  return results;
}

export function getNodesByDifficulty(maxDifficulty) {
  const results = [];
  for (const [id, node] of Object.entries(LEARNING_GRAPH)) {
    if (node.difficulty <= maxDifficulty) {
      results.push(node);
    }
  }
  return results;
}

export function getNodesByType(type) {
  const results = [];
  for (const [id, node] of Object.entries(LEARNING_GRAPH)) {
    if (node.type === type) {
      results.push(node);
    }
  }
  return results;
}

export function getRecommendedNext(currentNodeId, knownWords = []) {
  const node = getNode(currentNodeId);
  if (!node) return [];
  
  const connections = getConnections(currentNodeId);
  
  // Filter out already known words
  const unknown = connections.filter(conn => !knownWords.includes(conn));
  
  // Sort by difficulty
  const withDifficulty = unknown.map(id => ({
    id,
    node: getNode(id),
    difficulty: getNode(id)?.difficulty || 1
  }));
  
  withDifficulty.sort((a, b) => a.difficulty - b.difficulty);
  
  return withDifficulty.map(item => item.node).filter(Boolean);
}

export function getLearningPath(targetNodeId, knownWords = []) {
  // Generate a learning path from known words to the target
  const target = getNode(targetNodeId);
  if (!target) return [];
  
  const path = [];
  const visited = new Set();
  
  // BFS from target to find closest unknown word
  const queue = [{ id: targetNodeId, depth: 0 }];
  
  while (queue.length > 0) {
    const { id, depth } = queue.shift();
    if (visited.has(id)) continue;
    visited.add(id);
    
    const node = getNode(id);
    if (!node) continue;
    
    if (!knownWords.includes(id) && id !== targetNodeId) {
      path.push(node);
      break;
    }
    
    const connections = getConnections(id);
    for (const conn of connections) {
      if (!visited.has(conn)) {
        queue.push({ id: conn, depth: depth + 1 });
      }
    }
  }
  
  return path;
}