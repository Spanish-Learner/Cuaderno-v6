// src/utils/version.js

export function parseVersion(version) {
  if (!version || typeof version !== 'string') return [];
  const parts = version.split('.').map(part => {
    const num = Number(part);
    if (isNaN(num) || !/^\d+$/.test(part)) {
      return NaN;
    }
    return num;
  });
  return parts;
}

export function compareVersions(v1, v2) {
  const parts1 = parseVersion(v1);
  const parts2 = parseVersion(v2);
  
  if (parts1.some(p => isNaN(p))) {
    throw new Error(`Invalid version string: "${v1}"`);
  }
  if (parts2.some(p => isNaN(p))) {
    throw new Error(`Invalid version string: "${v2}"`);
  }
  
  const maxLength = Math.max(parts1.length, parts2.length);
  
  for (let i = 0; i < maxLength; i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;
    if (p1 !== p2) {
      return p1 < p2 ? -1 : 1;
    }
  }
  return 0;
}