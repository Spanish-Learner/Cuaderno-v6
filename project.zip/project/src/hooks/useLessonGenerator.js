// src/hooks/useLessonGenerator.js
import { useState, useCallback } from "react";
import {
  generateAdaptiveLesson,
  generateContextLesson,
  generateLesson
} from "../engine/lessonGenerator";

export default function useLessonGenerator() {
  const [lesson, setLesson] = useState(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);

  const generateAdaptive = useCallback(() => {
    setLoading(true);
    try {
      const generated = generateAdaptiveLesson();
      setLesson(generated);
      return generated;
    } finally {
      setLoading(false);
    }
  }, []);

  const generateContextual = useCallback((context) => {
    setLoading(true);
    try {
      const generated = generateContextLesson(context);
      setLesson(generated);
      return generated;
    } finally {
      setLoading(false);
    }
  }, []);

  const generateTopicLesson = useCallback((topic) => {
    setLoading(true);
    try {
      const generated = generateLesson(topic);
      setLesson(generated);
      return generated;
    } finally {
      setLoading(false);
    }
  }, []);

  const completeLesson = useCallback((lessonId) => {
    setHistory((prev) => [...prev, { id: lessonId, completedAt: new Date().toISOString() }]);
    setLesson(null);
  }, []);

  const getHistory = useCallback(() => history, [history]);

  const clearHistory = useCallback(() => setHistory([]), []);

  return {
    lesson,
    loading,
    history,
    generateAdaptive,
    generateContextual,
    generateTopicLesson,
    completeLesson,
    getHistory,
    clearHistory
  };
}
