export default function useLessonGenerator() {
  // ... existing implementation ...
  return {
    lesson,
    loading,
    history,
    generateAdaptive,
    generateContextual,
    generateTopicLesson,
    completeLesson,
    getHistory,
    clearHistory
  };
}