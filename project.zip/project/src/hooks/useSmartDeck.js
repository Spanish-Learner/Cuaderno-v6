// src/hooks/useSmartDeck.js
import { useState, useMemo } from 'react';
import { 
  calculateNextReview, 
  getDeckStats, 
  getBalancedStudyOrder,
  detectConfusionPairs,
  findRelatedWords,
  generateQuiz
} from '../engine/flashcardEngine';

export default function useSmartDeck(initialCards) {
  const [cards, setCards] = useState(initialCards);
  const [studyOrder, setStudyOrder] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [mode, setMode] = useState('study'); // 'study' | 'quiz' | 'confusion'
  const [quizQuestions, setQuizQuestions] = useState([]);
  const [quizIndex, setQuizIndex] = useState(0);

  const stats = useMemo(() => getDeckStats(cards), [cards]);
  const confusionPairs = useMemo(() => detectConfusionPairs(cards), [cards]);

  // === Study Session ===
  const startStudySession = (count = 20) => {
    const order = getBalancedStudyOrder(cards, count);
    setStudyOrder(order);
    setCurrentIndex(0);
    setMode('study');
    return order;
  };

  // === Review Card ===
  const reviewCard = (cardId, quality) => {
    const card = cards.find(c => c.id === cardId);
    if (!card) return;

    const updated = calculateNextReview(card, quality);
    const newCards = cards.map(c => 
      c.id === cardId ? { ...c, ...updated } : c
    );
    setCards(newCards);
    return updated;
  };

  // === Quiz Mode ===
  const startQuiz = (count = 5) => {
    const quiz = generateQuiz(cards, count);
    setQuizQuestions(quiz);
    setQuizIndex(0);
    setMode('quiz');
    return quiz;
  };

  const answerQuiz = (answer) => {
    const isCorrect = answer === quizQuestions[quizIndex].answer;
    const cardId = quizQuestions[quizIndex].cardId;
    
    // Update card based on quiz result
    reviewCard(cardId, isCorrect ? 2 : 0);
    
    const nextIndex = quizIndex + 1;
    if (nextIndex >= quizQuestions.length) {
      setMode('study');
      return { isCorrect, complete: true };
    }
    setQuizIndex(nextIndex);
    return { isCorrect, complete: false };
  };

  // === Confusion Pairs Mode ===
  const startConfusionSession = () => {
    if (confusionPairs.length === 0) return [];
    
    // Flatten confusion pairs into a study list
    const uniqueCards = [];
    const seen = new Set();
    confusionPairs.forEach(([a, b]) => {
      if (!seen.has(a.id)) { seen.add(a.id); uniqueCards.push(a); }
      if (!seen.has(b.id)) { seen.add(b.id); uniqueCards.push(b); }
    });
    
    setStudyOrder(uniqueCards);
    setCurrentIndex(0);
    setMode('confusion');
    return uniqueCards;
  };

  // === Similar Words ===
  const getSimilarWords = (cardId) => {
    const card = cards.find(c => c.id === cardId);
    if (!card) return [];
    return findRelatedWords(card, cards);
  };

  // === Current Card ===
  const currentCard = useMemo(() => {
    if (mode === 'quiz') return quizQuestions[quizIndex];
    if (studyOrder.length === 0) return null;
    return studyOrder[currentIndex];
  }, [mode, quizQuestions, quizIndex, studyOrder, currentIndex]);

  const nextCard = () => {
    if (currentIndex < studyOrder.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const prevCard = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  // === Reset ===
  const resetDeck = () => {
    const reset = cards.map(c => ({
      ...c,
      mastery: 0,
      ease: 2.5,
      interval: 0,
      nextReview: null,
      lastReviewed: null,
      reviewCount: 0,
      timesCorrect: 0,
      timesWrong: 0,
      streak: 0,
      maxStreak: 0
    }));
    setCards(reset);
    setStudyOrder([]);
    setCurrentIndex(0);
    setMode('study');
  };

  return {
    cards,
    currentCard,
    stats,
    mode,
    confusionPairs,
    quizQuestions,
    quizIndex,
    startStudySession,
    reviewCard,
    startQuiz,
    answerQuiz,
    startConfusionSession,
    getSimilarWords,
    nextCard,
    prevCard,
    resetDeck
  };
}