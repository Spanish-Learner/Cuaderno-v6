// src/hooks/useReasoning.js
import { useState } from "react";
import { getReasoningEngine } from "../engine/reasoningEngine";

export default function useReasoning() {
  const [engine] = useState(getReasoningEngine());
  const [analysis, setAnalysis] = useState(null);
  const [correction, setCorrection] = useState(null);
  const [explanation, setExplanation] = useState(null);

  const analyze = (sentence) => {
    const result = engine.analyzeSentence(sentence);
    setAnalysis(result);
    return result;
  };

  const correct = (sentence) => {
    const result = engine.generateFullCorrection(sentence);
    setCorrection(result);
    return result;
  };

  const explain = (original, corrected, reasons) => {
    const result = engine.answerWhy(original, corrected, reasons);
    setExplanation(result);
    return result;
  };

  const reset = () => {
    setAnalysis(null);
    setCorrection(null);
    setExplanation(null);
  };

  return {
    engine,
    analysis,
    correction,
    explanation,
    analyze,
    correct,
    explain,
    reset
  };
}