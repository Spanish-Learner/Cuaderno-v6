// src/hooks/useLanguageDatabase.js
import { useState, useEffect, useMemo } from "react";
import { getLanguageEngine } from "../engine/databaseLoader";

export default function useLanguageDatabase() {
  const [loaded, setLoaded] = useState(false);
  const [engine, setEngine] = useState(null);

  useEffect(() => {
    const eng = getLanguageEngine();
    setEngine(eng);
    setLoaded(true);
  }, []);

  const wordIndex = useMemo(() => {
    if (!engine) return {};
    return engine.words.reduce((idx, word) => {
      idx[word.word] = word;
      return idx;
    }, {});
  }, [engine]);

  return {
    loaded,
    engine,
    wordIndex,
    
    // Quick lookups
    getWord: (word) => wordIndex[word.toLowerCase()],
    getWordsByCategory: (category) => engine?.getWordsByCategory(category) || [],
    getWordsByLevel: (level) => engine?.getWordsByLevel(level) || [],
    getLexicalFamily: (word) => engine?.getLexicalFamily(word) || null,
    getRelatedWords: (word) => engine?.getRelatedWords(word) || [],
    search: (query) => engine?.search(query) || [],
    resolveConjugation: (form) => engine?.resolveConjugation(form) || null,
    
    // Stats
    stats: engine?.stats || {
      totalWords: 0,
      totalVerbs: 0,
      totalNouns: 0,
      totalAdjectives: 0,
      totalExpressions: 0,
      totalConjugatedForms: 0
    }
  };
}