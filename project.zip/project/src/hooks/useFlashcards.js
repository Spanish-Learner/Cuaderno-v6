// src/hooks/useFlashcards.js
import { useState, useMemo } from "react";
import { calculateNextReview } from "../engine/spacedRepetition";

export default function useFlashcards(deck) {
  const [cards, setCards] = useState(deck);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [shuffled, setShuffled] = useState(false);
  const [order, setOrder] = useState(() => cards.map((_, i) => i));

  const currentCard = useMemo(() => {
    return cards[order[currentIndex]];
  }, [cards, order, currentIndex]);

  const stats = useMemo(() => {
    const total = cards.length;
    const mastered = cards.filter(c => c.mastered).length;
    const learning = cards.filter(c => !c.mastered && c.reviewCount > 0).length;
    const newCards = cards.filter(c => c.reviewCount === 0).length;
    const dueToday = cards.filter(c => 
      c.nextReview && c.nextReview < Date.now() && !c.mastered
    ).length;

    return { total, mastered, learning, new: newCards, dueToday };
  }, [cards]);

  const goTo = (index) => {
    setCurrentIndex(Math.max(0, Math.min(index, cards.length - 1)));
  };

  const shuffle = () => {
    const shuffledOrder = [...order];
    for (let i = shuffledOrder.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffledOrder[i], shuffledOrder[j]] = [shuffledOrder[j], shuffledOrder[i]];
    }
    setOrder(shuffledOrder);
    setShuffled(!shuffled);
    setCurrentIndex(0);
  };

  const review = (quality) => {
    if (!currentCard) return;

    const updated = calculateNextReview(currentCard, quality);
    const newCards = [...cards];
    const cardIndex = order[currentIndex];
    newCards[cardIndex] = { ...newCards[cardIndex], ...updated };

    // Auto-mark as mastered after 5+ reviews with quality >= 3
    if (newCards[cardIndex].reviewCount >= 5 && newCards[cardIndex].streak >= 5) {
      newCards[cardIndex].mastered = true;
    }

    setCards(newCards);
    setCurrentIndex((i) => (i + 1) % cards.length);
  };

  const resetDeck = () => {
    const reset = cards.map(c => ({
      ...c,
      mastered: false,
      reviewCount: 0,
      lastReviewed: null,
      nextReview: null,
      streak: 0,
      maxStreak: 0,
      misses: 0,
      difficulty: 1,
      ease: 2.5,
      interval: 0
    }));
    setCards(reset);
    setCurrentIndex(0);
    setOrder(reset.map((_, i) => i));
    setShuffled(false);
  };

  return {
    cards,
    currentCard,
    currentIndex,
    stats,
    goTo,
    shuffle,
    review,
    resetDeck,
    isShuffled: shuffled
  };
}