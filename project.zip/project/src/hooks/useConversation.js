// src/hooks/useConversation.js
import { useState } from "react";
import { createConversationMemory, respond } from "../engine/conversation";

export default function useConversation() {
  const [memory, setMemory] = useState(createConversationMemory());

  const send = (message) => {
    const result = respond(message, memory);
    setMemory({ ...result.memory });
    return result.reply;
  };

  return {
    memory,
    send
  };
}