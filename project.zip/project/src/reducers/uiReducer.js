// src/reducers/uiReducer.js
export function uiReducer(state, action) {
  switch (action.type) {
    case 'SET_TAB':
      return { ...state, activeTab: action.payload };
    default:
      return state;
  }
}