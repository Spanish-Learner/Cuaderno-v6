// src/reducers/lessonReducer.js
export function lessonReducer(state, action) {
  switch (action.type) {
    case 'LESSON_COMPLETED':
      return {
        ...state,
        completed: [...(state.completed || []), action.payload]
      };
    case 'SET_CURRENT_LESSON':
      return {
        ...state,
        current: action.payload
      };
    default:
      return state;
  }
}