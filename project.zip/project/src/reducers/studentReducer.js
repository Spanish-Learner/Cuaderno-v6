// src/reducers/studentReducer.js
export function studentReducer(state, action) {
  switch (action.type) {
    case 'SET_STUDENT_NAME':
      return { ...state, name: action.payload };
    case 'ADD_KNOWN_WORD':
      return {
        ...state,
        knownWords: [...(state.knownWords || []), action.payload]
      };
    case 'UPDATE_STUDENT_LEVEL':
      return { ...state, level: action.payload };
    case 'ADD_XP':
      return { ...state, xp: (state.xp || 0) + action.payload };
    case 'UPDATE_STREAK':
      return { ...state, streak: action.payload };
    case 'UPDATE_ACCURACY':
      return { ...state, accuracy: action.payload };
    default:
      return state;
  }
}