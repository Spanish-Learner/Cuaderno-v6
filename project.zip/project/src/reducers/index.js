// src/reducers/index.js
import { createInitialState } from '../state/initialState';
import { studentReducer } from './studentReducer';
import { chatReducer } from './chatReducer';
import { translatorReducer } from './translatorReducer';
import { flashcardReducer } from './flashcardReducer';
import { uiReducer } from './uiReducer';
import { lessonReducer } from './lessonReducer';

export function rootReducer(state = createInitialState(), action) {
  switch (action.type) {
    case 'RESET_APP':
      return createInitialState();
    default:
      return {
        ...state,
        student: studentReducer(state.student, action),
        chat: chatReducer(state.chat, action),
        translator: translatorReducer(state.translator, action),
        flashcards: flashcardReducer(state.flashcards, action),
        ui: uiReducer(state.ui, action),
        lessons: lessonReducer(state.lessons, action)
      };
  }
}

export { createInitialState };