// src/reducers/chatReducer.js
export function chatReducer(state, action) {
  switch (action.type) {
    case 'ADD_CHAT_MESSAGE':
      return {
        ...state,
        history: [...(state.history || []), action.payload]
      };
    case 'SET_CHAT_DRAFT':
      return { ...state, draftMessage: action.payload };
    default:
      return state;
  }
}