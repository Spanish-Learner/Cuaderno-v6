// src/reducers/translatorReducer.js
export function translatorReducer(state, action) {
  switch (action.type) {
    case 'SET_TRANSLATOR_INPUT':
      return { ...state, input: action.payload };
    case 'SET_TRANSLATOR_OUTPUT':
      return { ...state, output: action.payload };
    case 'SET_TRANSLATOR_DIRECTION':
      return { ...state, direction: action.payload };
    case 'ADD_TRANSLATOR_HISTORY':
      return {
        ...state,
        history: [...(state.history || []), action.payload]
      };
    default:
      return state;
  }
}