// src/reducers/flashcardReducer.js
export function flashcardReducer(state, action) {
  switch (action.type) {
    case 'SET_FLASHCARD_DECK':
      return {
        ...state,
        currentDeckId: action.payload,
        currentCardIndex: 0
      };
    case 'SET_FLASHCARD_INDEX':
      return { ...state, currentCardIndex: action.payload };
    case 'TOGGLE_FLASHCARD_SHUFFLE':
      return { ...state, isShuffled: !state.isShuffled };
    default:
      return state;
  }
}