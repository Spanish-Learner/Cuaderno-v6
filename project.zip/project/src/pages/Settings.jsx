// src/pages/Settings.jsx
import React from 'react';
import { useApp } from '../context/AppContext';
import { getBootManager } from '../engine/bootManager';

export default function Settings() {
  const { dispatch } = useApp();

  const handleClearData = async () => {
    if (window.confirm('Are you sure you want to clear all local data? This cannot be undone.')) {
      const bootManager = getBootManager();
      await bootManager.reset();
      dispatch({ type: 'RESET_APP' });
      dispatch({ type: 'SET_TAB', payload: 'home' });
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>⚙️ Settings</h1>
      </div>

      <div className="settings-list">
        <div className="setting-item">
          <div className="setting-info">
            <h3>Your Name</h3>
            <p>Change how you appear in the app</p>
          </div>
          <input
            type="text"
            className="setting-input"
            value={state?.student?.name || ''}
            onChange={(e) => dispatch({ type: 'SET_STUDENT_NAME', payload: e.target.value })}
            placeholder="Enter your name"
          />
        </div>

        <div className="setting-item">
          <div className="setting-info">
            <h3>Theme</h3>
            <p>Dark / Light Mode</p>
          </div>
          <select className="setting-select" defaultValue="dark">
            <option value="dark">Dark</option>
            <option value="light">Light</option>
          </select>
        </div>

        <div className="setting-item">
          <div className="setting-info">
            <h3>Notifications</h3>
            <p>Enable daily streak reminders</p>
          </div>
          <div className="toggle-switch">
            <input type="checkbox" defaultChecked />
          </div>
        </div>

        <div className="setting-item">
          <div className="setting-info">
            <h3>Storage</h3>
            <p>Manage app data</p>
          </div>
          <button className="btn-danger" onClick={handleClearData}>Clear All Data</button>
        </div>
        
        <div className="setting-item">
          <div className="setting-info">
            <h3>About</h3>
            <p>Cuaderno v{state?.version || '6.0.2'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}