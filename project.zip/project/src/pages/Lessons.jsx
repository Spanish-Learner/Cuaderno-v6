// src/pages/Lessons.jsx
import React from 'react';
import { useApp } from '../context/AppContext';
import useLessonGenerator from '../hooks/useLessonGenerator';
import LessonView from '../components/LessonView';

export default function Lessons() {
  const { state, dispatch } = useApp();
  const { lesson, generateAdaptive, completeLesson, loading } = useLessonGenerator();

  const handleGenerateLesson = () => {
    generateAdaptive();
  };

  const handleCompleteLesson = (lessonId) => {
    completeLesson(lessonId);
    dispatch({ type: 'LESSON_COMPLETED', payload: { id: lessonId } });
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>📚 Lessons</h1>
        <button className="btn-primary" onClick={handleGenerateLesson} disabled={loading}>
          {loading ? 'Generating...' : 'Generate Adaptive Lesson'}
        </button>
      </div>

      {lesson && (
        <div className="active-lesson-container">
          <LessonView lesson={lesson} onComplete={handleCompleteLesson} />
        </div>
      )}

      {!lesson && !loading && (
        <div className="empty-state">
          <p>No active lesson. Click "Generate Adaptive Lesson" to start based on your recent mistakes.</p>
        </div>
      )}
    </div>
  );
}