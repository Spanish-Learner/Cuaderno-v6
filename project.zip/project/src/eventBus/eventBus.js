// src/eventBus/eventBus.js
import { Subscription } from './eventSubscription';

class EventBus {
  constructor() {
    this._listeners = new Map();
    this._subscriptions = new Map();
  }

  subscribe(event, handler) {
    let eventSubs = this._subscriptions.get(event);
    if (!eventSubs) {
      eventSubs = new Map();
      this._subscriptions.set(event, eventSubs);
    }

    if (eventSubs.has(handler)) {
      const existing = eventSubs.get(handler);
      if (existing.isActive()) return existing;
    }

    if (!this._listeners.has(event)) {
      this._listeners.set(event, new Set());
    }
    this._listeners.get(event).add(handler);

    const sub = new Subscription(this, event, handler);
    eventSubs.set(handler, sub);
    return sub;
  }

  once(event, handler) {
    let sub;
    const wrapper = (...args) => {
      sub.unsubscribe();
      handler(...args);
    };
    sub = this.subscribe(event, wrapper);
    return sub;
  }

  emit(event, payload) {
    const handlers = this._listeners.get(event);
    if (!handlers || handlers.size === 0) return;

    for (const handler of Array.from(handlers)) {
      try {
        handler(payload);
      } catch (err) {
        console.error(`Event handler failed for "${event}":`, err);
      }
    }
  }

  unsubscribe(event, handler) {
    const handlers = this._listeners.get(event);
    if (!handlers) return;
    handlers.delete(handler);
    if (handlers.size === 0) this._listeners.delete(event);

    const eventSubs = this._subscriptions.get(event);
    if (eventSubs) {
      eventSubs.delete(handler);
      if (eventSubs.size === 0) this._subscriptions.delete(event);
    }
  }

  unsubscribeAll(event) {
    const handlers = this._listeners.get(event);
    if (!handlers) return;

    const eventSubs = this._subscriptions.get(event);
    if (eventSubs) {
      for (const [, sub] of eventSubs) {
        sub._invalidate();
      }
    }

    this._listeners.delete(event);
    this._subscriptions.delete(event);
  }

  clear() {
    for (const [, eventSubs] of this._subscriptions) {
      for (const [, sub] of eventSubs) {
        sub._invalidate();
      }
    }
    this._listeners.clear();
    this._subscriptions.clear();
  }

  getStats() {
    let listenerCount = 0;
    for (const [, handlers] of this._listeners) {
      listenerCount += handlers.size;
    }
    let subscriptionCount = 0;
    for (const [, eventSubs] of this._subscriptions) {
      subscriptionCount += eventSubs.size;
    }
    return {
      events: this._listeners.size,
      listeners: listenerCount,
      subscriptions: subscriptionCount
    };
  }
}

export const eventBus = new EventBus();