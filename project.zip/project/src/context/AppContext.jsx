// src/context/AppContext.jsx
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { getBootManager } from '../engine/bootManager';
import { rootReducer, createInitialState } from '../reducers';
import { loadState, saveState } from '../engine/storage';
import { eventBus, EVENTS } from '../eventBus';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [state, setState] = useState(null);
  const [booted, setBooted] = useState(false);
  const [startupReport, setStartupReport] = useState(null);

  const dispatch = useCallback((action) => {
    setState(prev => {
      const newState = rootReducer(prev, action);
      eventBus.emit(EVENTS.STATE_CHANGED, { action, prevState: prev, newState });
      saveState(newState);
      return newState;
    });
  }, []);

  useEffect(() => {
    const init = async () => {
      const bootManager = getBootManager();
      const result = await bootManager.start();
      setStartupReport(result);
      const loadedState = loadState();
      setState(loadedState || createInitialState());
      setBooted(true);
    };
    init();
  }, []);

  useEffect(() => {
    const subscription = eventBus.subscribe(EVENTS.LESSON_COMPLETED, (payload) => {
      dispatch({ type: 'LESSON_COMPLETED', payload });
    });
    return () => subscription.unsubscribe();
  }, [dispatch]);

  const value = { state, booted, startupReport, dispatch };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}