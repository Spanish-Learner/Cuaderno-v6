// src/components/LessonView.jsx
import React, { useState } from "react";

export default function LessonView({ lesson, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState({});

  if (!lesson) return null;

  const handleNext = () => {
    if (currentStep < (lesson.steps?.length || 0) - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete?.(lesson.id);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const current = lesson.steps?.[currentStep];

  return (
    <div className="lesson-view">
      <div className="lesson-header">
        <h2>{lesson.title}</h2>
        <div className="lesson-progress">
          Step {currentStep + 1} of {lesson.steps?.length || 0}
        </div>
      </div>

      <div className="lesson-content">
        {current?.type === "explanation" && (
          <div className="explanation-content">{current.content}</div>
        )}
        {current?.type === "example" && (
          <div className="example-card">
            <div className="example-es">{current.spanish}</div>
            <div className="example-en">{current.english}</div>
          </div>
        )}
        {current?.type === "practice" && (
          <div className="practice-section">
            <p>{current.question}</p>
            <input
              className="practice-input"
              placeholder="Type your answer..."
              value={answers[currentStep] || ""}
              onChange={(e) => setAnswers({ ...answers, [currentStep]: e.target.value })}
            />
          </div>
        )}
      </div>

      <div className="lesson-controls">
        <button className="lesson-btn" onClick={handlePrevious} disabled={currentStep === 0}>
          ← Previous
        </button>
        <button className="lesson-btn primary" onClick={handleNext}>
          {currentStep === (lesson.steps?.length || 0) - 1 ? "Complete" : "Next →"}
        </button>
      </div>
    </div>
  );
}