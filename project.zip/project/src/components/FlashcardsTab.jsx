// src/components/FlashcardsTab.jsx
import React from 'react';
import { useApp } from '../context/AppContext';

export default function FlashcardsTab() {
  const { state, dispatch } = useApp();
  const deckId = state?.flashcards?.currentDeckId;
  const cardIndex = state?.flashcards?.currentCardIndex || 0;

  const nextCard = () => {
    dispatch({ type: 'SET_FLASHCARD_INDEX', payload: cardIndex + 1 });
  };

  return (
    <div className="flashcards-tab">
      <div className="flashcards-header">
        <h2>🃏 Flashcards</h2>
        <p>Deck: {deckId || 'None selected'}</p>
      </div>
      <div className="flashcard-view">
        <div className="flashcard-card">
          <div className="flashcard-front">Card #{cardIndex + 1}</div>
          <div className="flashcard-back">Flip to see answer</div>
        </div>
        <button className="btn-primary" onClick={nextCard}>Next Card</button>
      </div>
    </div>
  );
}