// src/engine/engineRegistry.js
import { deepFreeze } from '../utils/object';

export class EngineRegistry {
  constructor() {
    this._manifest = new Map();
    this._engines = new Map();
    this._statuses = new Map();
  }

  registerManifest(id, manifest) {
    this._manifest.set(id, deepFreeze(manifest));
  }
  getManifest(id) { return this._manifest.get(id); }

  registerStatus(id, status) { this._statuses.set(id, status); }
  getStatus(id) { return this._statuses.get(id); }
  getAllStatuses() { return new Map(this._statuses); }

  registerEngine(id, instance) { this._engines.set(id, instance); }
  getEngine(id) { return this._engines.get(id); }
  hasEngine(id) { return this._engines.has(id); }

  removeEngine(id) {
    if (!this._engines.has(id)) return false;
    this._engines.delete(id);
    return true;
  }

  dispose() {
    this._manifest.clear();
    this._engines.clear();
    this._statuses.clear();
  }
}