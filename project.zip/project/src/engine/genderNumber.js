// src/engine/genderNumber.js

// ============================================================
// GENDER DETECTION
// ============================================================

export function detectGender(word) {
  const lower = word.toLowerCase();
  
  // Common feminine endings
  if (lower.match(/a$|ción$|sión$|dad$|tad$|tud$|umbre$/)) {
    return "feminine";
  }
  
  // Common masculine endings
  if (lower.match(/o$|aje$|ón$|or$|ma$|ama$|ema$|oma$/)) {
    return "masculine";
  }
  
  // Special cases
  const exceptions = {
    "agua": "feminine",
    "mano": "feminine",
    "día": "masculine",
    "mapa": "masculine",
    "problema": "masculine",
    "sistema": "masculine",
    "tema": "masculine",
    "poema": "masculine",
    "clima": "masculine",
    "tranvía": "masculine"
  };
  
  if (exceptions[lower]) {
    return exceptions[lower];
  }
  
  return "unknown";
}

// ============================================================
// NUMBER DETECTION
// ============================================================

export function detectNumber(word) {
  const lower = word.toLowerCase();
  
  // Plural endings
  if (lower.match(/s$|es$|ces$/)) {
    return "plural";
  }
  
  // Always consider these plural
  const alwaysPlural = ["gafas", "pantalones", "tijeras", "alicates"];
  if (alwaysPlural.includes(lower)) {
    return "plural";
  }
  
  return "singular";
}

// ============================================================
// ARTICLE GENERATION
// ============================================================

export function getArticle(noun, gender = null, number = null) {
  const detectedGender = gender || detectGender(noun);
  const detectedNumber = number || detectNumber(noun);
  
  if (detectedNumber === "plural") {
    return detectedGender === "feminine" ? "las" : "los";
  }
  
  return detectedGender === "feminine" ? "la" : "el";
}

// ============================================================
// ARTICLE AGREEMENT CHECK
// ============================================================

export function checkArticleAgreement(article, noun) {
  const articleLower = article.toLowerCase();
  const nounGender = detectGender(noun);
  const nounNumber = detectNumber(noun);
  
  const expectedArticle = getArticle(noun, nounGender, nounNumber);
  
  return {
    matches: articleLower === expectedArticle,
    expected: expectedArticle,
    actual: articleLower,
    gender: nounGender,
    number: nounNumber
  };
}

// ============================================================
// GENDER/NUMBER INFO
// ============================================================

export function getGenderNumberInfo(word) {
  return {
    gender: detectGender(word),
    number: detectNumber(word),
    article: getArticle(word)
  };
}