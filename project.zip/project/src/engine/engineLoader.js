// src/engine/engineLoader.js
import { BootError } from '../utils/errors';
import { ENGINE_STATUS } from './engineStatus';
import { LIFECYCLE_STATE } from './engineLifecycle';

export class EngineLoader {
  constructor(registry) {
    this.registry = registry;
    this._activationPromises = new Map();
    this._timeoutMs = 30000;
    this._maxRetries = 3;
    this._retryCount = new Map();
  }

  register(engineDef) {
    const status = new EngineStatus(engineDef.id);
    if (engineDef.lazy) {
      status.markLazy();
    } else {
      status.markLoading();
    }
    this.registry.registerStatus(engineDef.id, status);
    this.registry.registerManifest(engineDef.id, engineDef);
    return status;
  }

  async initialize(id, context) {
    if (this._activationPromises.has(id)) {
      return this._activationPromises.get(id);
    }

    const promise = this._doInitialize(id, context);
    this._activationPromises.set(id, promise);

    try {
      return await promise;
    } finally {
      this._activationPromises.delete(id);
    }
  }

  async _doInitialize(id, context) {
    const status = this.registry.getStatus(id);
    if (!status) throw new BootError(`Engine "${id}" not registered`, { code: 'ENGINE_NOT_FOUND' });

    if (status.isReady() && this.registry.hasEngine(id)) {
      return this.registry.getEngine(id);
    }

    const manifest = this.registry.getManifest(id);
    if (!manifest) throw new BootError(`No manifest for "${id}"`, { code: 'NO_MANIFEST' });

    const lifecycle = new manifest.lifecycle();
    const controller = new AbortController();
    const signal = controller.signal;

    const timeoutId = setTimeout(() => {
      controller.abort(new BootError(`Engine "${id}" initialization timed out`, { code: 'TIMEOUT' }));
    }, this._timeoutMs);

    signal.addEventListener('abort', () => clearTimeout(timeoutId), { once: true });

    try {
      await Promise.race([
        lifecycle.initialize(context, signal),
        new Promise((_, reject) => {
          signal.addEventListener('abort', (e) => reject(e.target.reason), { once: true });
        })
      ]);

      clearTimeout(timeoutId);
      this.registry.registerEngine(id, lifecycle);
      status.markReady();
      return lifecycle;

    } catch (error) {
      clearTimeout(timeoutId);
      await lifecycle.dispose();
      status.markFailed(error);
      throw error;
    }
  }

  async activateLazy(id, context) {
    return this.initialize(id, context);
  }

  async restart(id, context) {
    const status = this.registry.getStatus(id);
    if (!status) return false;

    if (this._activationPromises.has(id)) {
      await this._activationPromises.get(id);
    }

    const manifest = this.registry.getManifest(id);
    if (manifest) {
      for (const dep of manifest.dependencies) {
        const depStatus = this.registry.getStatus(dep);
        if (depStatus && (depStatus.isFailed() || depStatus.isDisabled())) {
          throw new BootError(`Cannot restart "${id}" due to failed dependency "${dep}"`, { code: 'DEPENDENCY_FAILED' });
        }
      }
    }

    const oldInstance = this.registry.getEngine(id);
    if (oldInstance) {
      await oldInstance.dispose();
      this.registry.removeEngine(id);
    }

    status.markLoading();
    try {
      await this.initialize(id, context);
      return true;
    } catch (error) {
      status.markFailed(error);
      return false;
    }
  }

  getStatus(id) { return this.registry.getStatus(id); }
}