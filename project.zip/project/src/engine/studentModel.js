// src/engine/studentModel.js
import { loadState, saveState } from './storage';

export function getStudentStats(student) {
  if (!student) {
    return {
      level: 'A1',
      xp: 0,
      streak: 0,
      accuracy: 0,
      knownWords: 0,
      weakWords: 0,
      totalMistakes: 0,
      sessionsCompleted: 0,
      mistakes: {}
    };
  }

  const totalMistakes = Object.values(student.mistakes || {}).reduce(
    (sum, category) => sum + Object.values(category || {}).reduce((a, b) => a + b, 0),
    0
  );

  return {
    level: student.level || 'A1',
    xp: student.xp || 0,
    streak: student.streak || 0,
    accuracy: student.accuracy || 0,
    knownWords: student.knownWords?.length || 0,
    weakWords: student.weakWords?.length || 0,
    totalMistakes,
    sessionsCompleted: student.sessionsCompleted || 0,
    mistakes: student.mistakes || {}
  };
}

export function resetStudent() {
  const { createInitialState } = require('../state/initialState');
  return createInitialState().student;
}