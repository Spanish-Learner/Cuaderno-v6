// src/engine/spacedRepetition.js

// SM-2 algorithm adapted for offline use
// interval: days between reviews
// ease: multiplier (2.5 default, higher = easier)

export function calculateNextReview(card, quality) {
  // quality: 0=forgot, 1=hard, 2=okay, 3=easy, 4=very easy, 5=perfect
  const now = Date.now();

  let ease = card.ease || 2.5;
  let interval = card.interval || 0;

  if (quality < 3) {
    // Reset if forgotten or hard
    interval = 0;
    ease = Math.max(1.3, ease - 0.2);
  } else {
    // Successful recall
    if (interval === 0) {
      interval = 1; // 1 day
    } else if (interval === 1) {
      interval = 6; // 6 days
    } else {
      interval = Math.round(interval * ease);
    }
    ease = Math.min(2.5, ease + 0.15);
  }

  const nextReview = now + interval * 24 * 60 * 60 * 1000;

  return {
    interval,
    ease,
    nextReview,
    lastReviewed: now,
    reviewCount: (card.reviewCount || 0) + 1,
    misses: quality < 3 ? (card.misses || 0) + 1 : card.misses || 0,
    streak: quality >= 3 ? (card.streak || 0) + 1 : 0,
    maxStreak: Math.max(card.maxStreak || 0, quality >= 3 ? (card.streak || 0) + 1 : 0),
    difficulty: calculateDifficulty(card, quality)
  };
}

function calculateDifficulty(card, quality) {
  // 1 = easiest, 5 = hardest
  const base = card.difficulty || 3;
  const adjustment = (5 - quality) * 0.2;
  const missesPenalty = (card.misses || 0) * 0.05;
  return Math.max(1, Math.min(5, base + adjustment + missesPenalty));
}