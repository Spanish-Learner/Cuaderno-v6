// src/engine/conjugationResolver.js
import { resolveConjugation, getGrammaticalFeatures, getVerbForms, getDetailedConjugationInfo } from "./conjugationIndex";

// Re-export for backward compatibility
export { resolveConjugation, getGrammaticalFeatures, getVerbForms, getDetailedConjugationInfo } from "./conjugationIndex";

// Enhanced: Get detailed info including person/number
export function getDetailedConjugationInfo(form) {
  const info = getGrammaticalFeatures(form);
  if (!info) return null;

  const personMap = {
    1: "first",
    2: "second",
    3: "third"
  };

  const numberMap = {
    1: "singular",
    2: "singular", // tú
    3: "singular", // él/ella/usted
    4: "plural", // nosotros
    5: "plural", // vosotros
    6: "plural" // ellos/ellas/ustedes
  };

  return {
    ...info,
    personName: info.person ? personMap[info.person] : null,
    number: info.person ? numberMap[info.person] : null,
    fullDescription: info.person 
      ? `${info.base} (${info.tense}, ${personMap[info.person]} person ${numberMap[info.person]})`
      : `${info.base} (${info.tense})`
  };
}

// Conjugate a verb in a specific tense (for generation)
export function conjugateVerb(infinitive, tense) {
  return getVerbForms(infinitive, tense);
}

// Check if a word is a conjugated form
export function isConjugatedForm(word) {
  return !!resolveConjugation(word);
}

// Get the infinitive from a conjugated form
export function getInfinitiveFromForm(form) {
  const resolved = resolveConjugation(form);
  return resolved ? resolved.base : null;
}

// Get the Spanish infinitive from a conjugated form
export function getSpanishInfinitiveFromForm(form) {
  const resolved = resolveConjugation(form);
  return resolved ? resolved.base : null;
}