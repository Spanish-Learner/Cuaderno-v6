// src/engine/contextAnalyzer.js
import { parseSentence } from "./parser";

export function detectTime(tokens) {
  const textTokens = tokens
    .filter(t => t.type === "word")
    .map(t => t.text);
  
  if (textTokens.some(x => x === "ayer" || x === "ayer")) return "past";
  if (textTokens.some(x => x === "mañana" || x === "mañana")) return "future";
  if (textTokens.some(x => x === "ahora" || x === "ahora")) return "present";
  return "unknown";
}

export function detectFormality(tokens) {
  const textTokens = tokens
    .filter(t => t.type === "word")
    .map(t => t.text);
  
  if (textTokens.some(x => x === "usted" || x === "ustedes")) return "formal";
  if (textTokens.some(x => x === "tú" || x === "vosotros")) return "informal";
  return "neutral";
}

export function detectEmotion(tokens) {
  const textTokens = tokens
    .filter(t => t.type === "word")
    .map(t => t.text);
  
  const emotions = {
    happy: ["feliz", "alegre", "contento", "bien", "genial"],
    sad: ["triste", "mal", "llorar", "dolor"],
    angry: ["enojado", "enfadado", "furioso", "cabreado"],
    surprised: ["sorprendido", "increíble", "no puedo creer"],
    scared: ["miedo", "asustado", "terror", "pánico"]
  };

  for (const [emotion, words] of Object.entries(emotions)) {
    if (textTokens.some(x => words.includes(x))) {
      return emotion;
    }
  }
  return "neutral";
}

export function analyzeContext(sentence) {
  const parse = parseSentence(sentence);
  const { tokens, structure } = parse;
  
  return {
    time: detectTime(tokens),
    formality: detectFormality(tokens),
    emotion: detectEmotion(tokens),
    isQuestion: structure.question,
    isExclamation: structure.exclamation,
    hasVerb: !!structure.verb,
    hasSubject: !!structure.subject,
    wordCount: tokens.length,
    structure
  };
}