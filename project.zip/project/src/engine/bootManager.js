// src/engine/bootManager.js
import { loadState, saveState } from './storage';
import { EngineRegistry } from './engineRegistry';
import { getStateMigrator } from './stateMigrator';
import { StartupReporter } from './startupReporter';
import { EngineLoader } from './engineLoader';
import { DependencyGraph } from './dependencyGraph';
import { ENGINE_MANIFEST } from '../manifests/engineManifest';
import { deepClone } from '../utils/object';
import { BootError } from '../utils/errors';
import { eventBus, EVENTS } from '../eventBus';

export class BootManager {
  constructor() {
    this.registry = new EngineRegistry();
    this.loader = new EngineLoader(this.registry);
    this.migrator = getStateMigrator();
    this.reporter = new StartupReporter();
    this.graph = null;
    this.state = null;
    this.failedEngines = new Set();
    this._booted = false;
    this._bootError = null;
  }

  async start() {
    eventBus.emit(EVENTS.BOOT_STARTED, { timestamp: Date.now() });

    try {
      this.graph = new DependencyGraph(ENGINE_MANIFEST);
      const order = this.graph.topologicalSort();

      // State loading is now handled by AppContext
      // BootManager only orchestrates engines

      for (const id of order) {
        const ctx = this.loader.getContext(id);
        if (ctx.manifest.lazy) continue;
        try {
          await this.loader.start(id, {});
        } catch (error) {
          this.failedEngines.add(id);
        }
      }

      if (this.failedEngines.size > 0) {
        const affected = this.graph.getAffectedByFailures(this.failedEngines);
        for (const id of affected) {
          await this.loader.stop(id, 'dependency_failure');
          this.failedEngines.add(id);
        }
      }

      const success = this.failedEngines.size === 0;
      eventBus.emit(EVENTS.BOOT_COMPLETED, { success, failedEngines: Array.from(this.failedEngines) });

      this._booted = true;
      return { success, failedEngines: Array.from(this.failedEngines) };

    } catch (error) {
      eventBus.emit(EVENTS.BOOT_COMPLETED, { success: false, error: error.message });
      this._booted = false;
      this._bootError = error;
      throw error;
    }
  }

  async reset() {
    const { clearState } = await import('./storage');
    clearState();

    this.registry = new EngineRegistry();
    this.loader = new EngineLoader(this.registry);
    this.migrator = getStateMigrator();
    this.reporter = new StartupReporter();
    this.graph = null;
    this.state = null;
    this.failedEngines = new Set();
    this._booted = false;
    this._bootError = null;

    await this.start();
  }

  getContext() {
    return {
      booted: this._booted,
      error: this._bootError,
      registry: this.registry,
      loader: this.loader,
      reporter: this.reporter
    };
  }
}

let instance = null;
export function getBootManager() {
  if (!instance) instance = new BootManager();
  return instance;
}