// src/engine/entities.js

// ============================================================
// ENTITY DATABASES
// ============================================================

const countries = [
  // Original
  "españa", "méxico", "argentina", "pakistán", "francia", "italia",
  "alemania", "inglaterra", "portugal", "brasil", "chile", "perú",
  "colombia", "venezuela", "ecuador", "bolivia", "paraguay", "uruguay",
  "costa rica", "panamá", "cuba", "puerto rico", "república dominicana",

  // +20 new countries
  "estados unidos", "canadá", "australia", "japón", "china", "india",
  "rusia", "corea del sur", "sudáfrica", "egipto", "marruecos", "nigeria",
  "turquía", "grecia", "polonia", "ucrania", "suecia", "noruega",
  "finlandia", "irlanda"
];

const foods = [
  "pizza", "hamburguesa", "taco", "paella", "pasta", "ensalada",
  "sopa", "arroz", "frijoles", "carne", "pescado", "pollo",
  "verduras", "frutas", "manzana", "plátano", "naranja", "limón"
];

const cities = [
  "madrid", "barcelona", "buenos aires", "ciudad de méxico", "lima",
  "santiago", "caracas", "quito", "la paz", "montevideo", "asunción"
];

const sports = [
  "fútbol", "baloncesto", "tenis", "natación", "ciclismo", "atletismo",
  "voleibol", "béisbol", "golf", "esquí", "patinaje", "boxeo"
];

const colors = [
  "rojo", "azul", "verde", "amarillo", "naranja", "morado", "rosa",
  "negro", "blanco", "gris", "marrón", "dorado", "plateado"
];

// ============================================================
// ENTITY DETECTION
// ============================================================

export function detectEntities(tokens) {
  const result = {
    countries: [],
    foods: [],
    cities: [],
    sports: [],
    colors: [],
    names: [],
    other: []
  };

  tokens.forEach(token => {
    const word = token.text ? token.text.toLowerCase() : "";
    
    if (countries.includes(word)) {
      result.countries.push(word);
    } else if (foods.includes(word)) {
      result.foods.push(word);
    } else if (cities.includes(word)) {
      result.cities.push(word);
    } else if (sports.includes(word)) {
      result.sports.push(word);
    } else if (colors.includes(word)) {
      result.colors.push(word);
    } else if (isName(word)) {
      result.names.push(word);
    } else {
      result.other.push(word);
    }
  });

  return result;
}

// ============================================================
// NAME DETECTION
// ============================================================

function isName(word) {
  // Common Spanish names + Brianna
  const names = [
    "taha", "juan", "maría", "carlos", "ana", "pedro", "laura", 
    "josé", "luis", "miguel", "javier", "carmen", "rosa", "manuel",
    "brianna"
  ];
  return names.includes(word.toLowerCase());
}

// ============================================================
// UTILITY FUNCTIONS
// ============================================================

export function getAllEntityTypes() {
  return {
    countries,
    foods,
    cities,
    sports,
    colors,
    names: ["taha", "juan", "maría", "carlos", "ana", "pedro", "laura", 
      "josé", "luis", "miguel", "javier", "carmen", "rosa", "manuel",
      "brianna"]
  };
}

export function isEntity(word) {
  const lower = word.toLowerCase();
  const allEntities = [
    ...countries, ...foods, ...cities, ...sports, ...colors,
    "taha", "juan", "maría", "carlos", "ana", "pedro", "laura", 
    "josé", "luis", "miguel", "javier", "carmen", "rosa", "manuel",
    "brianna"
  ];
  return allEntities.includes(lower);
}