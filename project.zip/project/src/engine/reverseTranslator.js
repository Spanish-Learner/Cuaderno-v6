// src/engine/reverseTranslator.js

// ============================================================
// SIMPLE ENGLISH → SPANISH REVERSE TRANSLATOR
// ============================================================

export function translateEnglishToSpanish(text, dictionary) {
  const words = text
    .toLowerCase()
    .replace(/[.,!?]/g, "")
    .split(/\s+/);

  return words
    .map(word => {
      if (dictionary) {
        const entry = dictionary.find(item =>
          item.en && item.en.toLowerCase() === word
        );
        if (entry) return entry.es;
      }
      return `[${word}]`;
    })
    .join(" ");
}

// ============================================================
// HELPER: REVERSE LOOKUP FOR SINGLE WORDS
// ============================================================

export function reverseLookup(englishWord, dictionary) {
  if (!dictionary) return null;
  const entry = dictionary.find(item =>
    item.en && item.en.toLowerCase() === englishWord.toLowerCase()
  );
  return entry ? entry.es : null;
}

// ============================================================
// LEGACY EXPORT (for backward compatibility)
// ============================================================

export function translateEnglish(sentence, dictionary) {
  return translateEnglishToSpanish(sentence, dictionary);
}