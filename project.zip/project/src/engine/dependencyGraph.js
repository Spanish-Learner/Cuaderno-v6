// src/engine/dependencyGraph.js
import { BootError } from '../utils/errors';

export class DependencyGraph {
  constructor(manifest) {
    this.manifest = manifest;
    this.engineMap = new Map();
    this.dependents = new Map();

    for (const engine of manifest) {
      this.engineMap.set(engine.id, engine);
      this.dependents.set(engine.id, []);
    }

    for (const engine of manifest) {
      for (const dep of engine.dependencies) {
        if (!this.engineMap.has(dep)) {
          throw new BootError(`Missing dependency "${dep}" for "${engine.id}"`, { code: 'MISSING_DEPENDENCY' });
        }
        this.dependents.get(dep).push(engine.id);
      }
    }
  }

  topologicalSort() {
    const inDegree = new Map();
    for (const engine of this.manifest) {
      inDegree.set(engine.id, engine.dependencies.length);
    }

    const queue = [];
    for (const [id, deg] of inDegree) {
      if (deg === 0) queue.push(id);
    }

    const order = [];
    let head = 0;
    while (head < queue.length) {
      const node = queue[head++];
      order.push(node);
      for (const depId of (this.dependents.get(node) || [])) {
        inDegree.set(depId, inDegree.get(depId) - 1);
        if (inDegree.get(depId) === 0) {
          queue.push(depId);
        }
      }
    }

    if (order.length !== this.manifest.length) {
      throw new BootError('Dependency cycle detected', { code: 'DEPENDENCY_CYCLE' });
    }
    return order;
  }

  getAffectedByFailures(failedIds) {
    const affected = new Set(failedIds);
    const queue = Array.from(failedIds);

    while (queue.length > 0) {
      const id = queue.shift();
      for (const depId of (this.dependents.get(id) || [])) {
        if (!affected.has(depId)) {
          affected.add(depId);
          queue.push(depId);
        }
      }
    }

    return affected;
  }
}