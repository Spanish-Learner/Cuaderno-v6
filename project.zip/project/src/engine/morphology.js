// src/engine/morphology.js
import { resolveConjugation } from "./conjugationResolver";

export function analyzeWord(word) {
  const verb = resolveConjugation(word);
  if (verb) {
    return {
      type: "verb",
      base: verb.base,
      english: verb.base, // Will be enhanced with actual translation later
      form: word,
      tense: verb.tense,
      person: verb.person || null,
      regular: verb.regular,
      raw: verb
    };
  }
  return {
    type: "word",
    text: word
  };
}

// Detect if a word is a known pronoun
export function isPronoun(word) {
  const pronouns = [
    "yo", "tú", "él", "ella", "usted", 
    "nosotros", "nosotras", "vosotros", "vosotras", 
    "ellos", "ellas", "ustedes",
    "me", "te", "se", "le", "lo", "la", 
    "nos", "os", "les", "los", "las"
  ];
  return pronouns.includes(word.toLowerCase());
}

// Detect if a word is a preposition
export function isPreposition(word) {
  const prepositions = [
    "a", "ante", "bajo", "con", "contra", 
    "de", "desde", "durante", "en", "entre", 
    "hacia", "hasta", "para", "por", "según", 
    "sin", "so", "sobre", "tras"
  ];
  return prepositions.includes(word.toLowerCase());
}

// Detect if a word is an article
export function isArticle(word) {
  const articles = ["el", "la", "los", "las", "un", "una", "unos", "unas"];
  return articles.includes(word.toLowerCase());
}

// Detect if a word is a conjunction
export function isConjunction(word) {
  const conjunctions = [
    "y", "e", "o", "u", "pero", "porque", 
    "que", "si", "aunque", "mientras", 
    "cuando", "donde", "como"
  ];
  return conjunctions.includes(word.toLowerCase());
}

// Detect if a word is a possessive adjective
export function isPossessive(word) {
  const possessives = ["mi", "tu", "su", "nuestro", "vuestro", "mis", "tus", "sus"];
  return possessives.includes(word.toLowerCase());
}

// Detect if a word is a demonstrative
export function isDemonstrative(word) {
  const demonstratives = [
    "este", "esta", "estos", "estas", 
    "ese", "esa", "esos", "esas", 
    "aquel", "aquella", "aquellos", "aquellas"
  ];
  return demonstratives.includes(word.toLowerCase());
}

// Get the part of speech for a word
export function getPartOfSpeech(word) {
  if (isPronoun(word)) return "pronoun";
  if (isPreposition(word)) return "preposition";
  if (isArticle(word)) return "article";
  if (isConjunction(word)) return "conjunction";
  if (isPossessive(word)) return "possessive";
  if (isDemonstrative(word)) return "demonstrative";
  return "unknown";
}