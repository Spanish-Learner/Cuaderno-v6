// src/engine/explainCorrection.js
import { getLearningGraphEngine } from "./learningGraphEngine";
import { getLanguageEngine } from "./databaseLoader";

export function explainCorrection(original, corrected, reasons) {
  if (!reasons || reasons.length === 0) {
    return {
      original,
      corrected,
      explanation: "No correction needed. ¡Perfecto!",
      examples: [],
      practice: null
    };
  }

  // Build a detailed explanation
  const explanation = reasons.map((reason, i) => {
    return `${i + 1}. ${reason}`;
  }).join("\n");

  // Find related examples from the learning graph
  const graphEngine = getLearningGraphEngine();
  const examples = [];
  
  // Try to find examples related to the correction
  const words = original.split(/\s+/);
  for (const word of words) {
    const related = graphEngine.getRelatedWords(word, 1);
    if (related.length > 0) {
      examples.push({
        original: `Example with "${word}":`,
        corrected: `Correct usage of "${word}" in context.`
      });
      break;
    }
  }

  // Generate a practice exercise
  const practice = generatePracticeFromCorrection(original, corrected, reasons);

  return {
    original,
    corrected,
    explanation,
    examples: examples.length > 0 ? examples : [{ original: "No related examples found.", corrected: "" }],
    practice
  };
}

function generatePracticeFromCorrection(original, corrected, reasons) {
  // Parse the correction to find what was fixed
  const changedWords = [];
  const origWords = original.split(/\s+/);
  const corrWords = corrected.split(/\s+/);
  
  for (let i = 0; i < Math.min(origWords.length, corrWords.length); i++) {
    if (origWords[i] !== corrWords[i]) {
      changedWords.push({ original: origWords[i], corrected: corrWords[i] });
    }
  }

  if (changedWords.length > 0) {
    // Create a fill-in-the-blank exercise
    const blankSentence = corrected.replace(changedWords[0].corrected, "______");
    return {
      type: "fill",
      question: `Complete the sentence: "${blankSentence}"`,
      answer: changedWords[0].corrected,
      hint: `The correct form is "${changedWords[0].corrected}"`
    };
  }

  return {
    type: "translate",
    question: `Translate this sentence to Spanish: "${corrected}"`,
    answer: corrected
  };
}