// src/engine/parser.js
import { analyzeWord, isPronoun, isPreposition, isArticle, isConjunction } from "./morphology";
import { detectTense, detectPerson } from "./sentenceParser";

export function parseSentence(sentence) {
  const words = sentence
    .replace(/[¿?¡!.,]/g, "")
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);

  const tokens = words.map(analyzeWord);
  
  // Add grammatical role to each token
  const enhancedTokens = tokens.map((token, index) => {
    const word = token.text || token.base || "";
    const role = {
      isPronoun: isPronoun(word),
      isPreposition: isPreposition(word),
      isArticle: isArticle(word),
      isConjunction: isConjunction(word),
      position: index
    };
    return { ...token, ...role };
  });

  // Build sentence structure
  const structure = buildSentenceStructure(enhancedTokens);

  return {
    tokens: enhancedTokens,
    structure,
    raw: sentence,
    wordCount: tokens.length
  };
}

function buildSentenceStructure(tokens) {
  const result = {
    subject: null,
    verb: null,
    objects: [],
    modifiers: [],
    prepositions: [],
    timeMarker: null,
    question: false,
    exclamation: false
  };

  // Find verb first (this is the anchor)
  const verbToken = tokens.find(t => t.type === "verb");
  if (verbToken) {
    result.verb = {
      word: verbToken.base || verbToken.text,
      form: verbToken.form || verbToken.text,
      tense: detectTense(verbToken.form || ""),
      person: detectPerson(verbToken.form || ""),
      raw: verbToken
    };
  }

  // Find subject (pronoun before verb)
  const verbIndex = tokens.indexOf(verbToken);
  if (verbIndex > 0) {
    const beforeVerb = tokens.slice(0, verbIndex);
    const subject = beforeVerb.find(t => t.isPronoun);
    if (subject) {
      result.subject = {
        word: subject.text,
        type: "pronoun",
        raw: subject
      };
    }
  }

  // Find objects (words after verb)
  if (verbIndex !== -1 && verbIndex < tokens.length - 1) {
    const afterVerb = tokens.slice(verbIndex + 1);
    result.objects = afterVerb
      .filter(t => t.type === "word" && !t.isPreposition && !t.isArticle)
      .map(t => ({ word: t.text, raw: t }));
    
    // Find prepositions and their objects
    let currentPrep = null;
    afterVerb.forEach(t => {
      if (t.isPreposition) {
        currentPrep = { preposition: t.text, object: null };
        result.prepositions.push(currentPrep);
      } else if (currentPrep && !t.isArticle) {
        currentPrep.object = t.text;
        currentPrep = null;
      }
    });
  }

  // Find time markers
  const timeWords = ["ayer", "hoy", "mañana", "ahora", "luego", "después", "antes", "siempre", "nunca", "ya", "todavía"];
  const timeToken = tokens.find(t => 
    t.type === "word" && timeWords.includes(t.text)
  );
  if (timeToken) {
    result.timeMarker = timeToken.text;
  }

  // Detect question/exclamation
  const raw = tokens.map(t => t.text || t.base).join(" ");
  result.question = raw.includes("¿") || raw.includes("?");
  result.exclamation = raw.includes("¡") || raw.includes("!");

  return result;
}

// Helper to get a human-readable representation of the parsed structure
export function formatParsedStructure(parse) {
  const lines = [];
  const { structure } = parse;
  
  if (structure.subject) {
    lines.push(`Subject: ${structure.subject.word}`);
  }
  if (structure.verb) {
    lines.push(`Verb: ${structure.verb.word} (${structure.verb.tense}, ${structure.verb.person})`);
  }
  if (structure.objects.length > 0) {
    lines.push(`Object(s): ${structure.objects.map(o => o.word).join(", ")}`);
  }
  if (structure.prepositions.length > 0) {
    structure.prepositions.forEach(p => {
      lines.push(`Preposition: ${p.preposition} → ${p.object || "?"}`);
    });
  }
  if (structure.timeMarker) {
    lines.push(`Time: ${structure.timeMarker}`);
  }
  if (structure.question) {
    lines.push("Type: Question");
  }
  if (structure.exclamation) {
    lines.push("Type: Exclamation");
  }
  
  return lines.join("\n");
}