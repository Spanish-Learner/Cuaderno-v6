// src/engine/startupReporter.js
export class StartupReporter {
  constructor() {
    this.report = {
      engines: {},
      totalTime: 0,
      errors: [],
      timestamp: null,
      memoryUsed: 0,
      engineCount: 0,
      lazyCount: 0
    };
    this.startTime = null;
  }

  start() {
    this.startTime = Date.now();
    this.report.timestamp = new Date().toISOString();
  }

  collect(name, snapshot) {
    this.report.engines[name] = snapshot;
  }

  addError(error) {
    this.report.errors.push(error);
  }

  finish() {
    this.report.totalTime = Date.now() - this.startTime;
    this.report.engineCount = Object.keys(this.report.engines).length;
    this.report.lazyCount = Object.values(this.report.engines)
      .filter(e => e.isLazy).length;
    
    if (performance.memory) {
      this.report.memoryUsed = performance.memory.usedJSHeapSize;
    }

    return this.report;
  }

  getReport() {
    return this.report;
  }
}