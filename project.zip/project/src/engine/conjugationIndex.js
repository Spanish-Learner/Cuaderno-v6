// src/engine/conjugationIndex.js
import { generateRegularConjugations, getVerbType, isRegular } from "./conjugator";
import { IRREGULAR_VERB_LIST } from "../data/irregularConjugations";

// ============================================================
// BUILD CONJUGATION INDEX
// ============================================================

export function buildConjugationIndex(regularVerbs, irregularVerbs = IRREGULAR_VERB_LIST) {
  const index = {};

  // 1. Add irregular verbs (explicitly stored)
  for (const verb of irregularVerbs) {
    const infinitive = verb.infinitive;
    const type = verb.type || getVerbType(infinitive);

    for (const [tense, forms] of Object.entries(verb)) {
      if (tense === "infinitive" || tense === "type") continue;

      if (Array.isArray(forms)) {
        forms.forEach((form, person) => {
          index[form] = {
            base: infinitive,
            tense,
            person: person + 1, // 1-6
            type,
            regular: false
          };
        });
      } else if (typeof forms === "string") {
        // Participle or single form
        index[forms] = {
          base: infinitive,
          tense,
          type,
          regular: false,
          isParticiple: true
        };
      }
    }
  }

  // 2. Add regular verbs (generated)
  for (const infinitive of regularVerbs) {
    if (isRegular(infinitive)) {
      const type = getVerbType(infinitive);
      const conjugations = generateRegularConjugations(infinitive);

      for (const [tense, forms] of Object.entries(conjugations)) {
        if (typeof forms === "string") {
          // Participle
          index[forms] = {
            base: infinitive,
            tense,
            type,
            regular: true,
            isParticiple: true
          };
        } else if (Array.isArray(forms)) {
          forms.forEach((form, person) => {
            index[form] = {
              base: infinitive,
              tense,
              person: person + 1,
              type,
              regular: true
            };
          });
        }
      }
    }
  }

  return index;
}

// ============================================================
// DEFAULT VERB LIST
// ============================================================

export const DEFAULT_REGULAR_VERBS = [
  "hablar", "comer", "vivir", "tomar", "beber", "caminar", "trabajar",
  "estudiar", "aprender", "enseñar", "mirar", "escuchar", "leer", "escribir",
  "preguntar", "responder", "explicar", "entender", "necesitar", "usar",
  "llevar", "traer", "dejar", "pasar", "quedar", "parecer", "creer",
  "recibir", "pedir", "pagar", "vender", "comprar", "encontrar", "buscar",
  "perder", "ganar", "jugar", "correr", "saltar", "nadar", "viajar",
  "llegar", "salir", "volver", "entrar", "subir", "bajar", "abrir",
  "cerrar", "cambiar", "decidir", "conocer"
];

// ============================================================
// BUILD THE INDEX ONCE AT STARTUP
// ============================================================

export const CONJUGATION_INDEX = buildConjugationIndex(DEFAULT_REGULAR_VERBS);

// ============================================================
// LOOKUP FUNCTIONS
// ============================================================

// Resolve a conjugated form to its base verb and tense
export function resolveConjugation(form) {
  const lower = form.toLowerCase().trim();
  return CONJUGATION_INDEX[lower] || null;
}

// Check if a word is a conjugated verb form
export function isConjugatedForm(word) {
  return !!resolveConjugation(word);
}

// Get all forms for a verb (for flashcards, quizzes, etc.)
export function getVerbForms(infinitive, tense = null) {
  // Check if irregular first
  const irregular = IRREGULAR_VERB_LIST.find(v => v.infinitive === infinitive);
  if (irregular) {
    if (tense) {
      return irregular[tense] || null;
    }
    return irregular;
  }

  // Regular verb
  if (tense) {
    const conjugations = generateRegularConjugations(infinitive);
    return conjugations?.[tense] || null;
  }

  return generateRegularConjugations(infinitive);
}

// Get grammatical features of a form
export function getGrammaticalFeatures(form) {
  const resolved = resolveConjugation(form);
  if (!resolved) return null;

  return {
    base: resolved.base,
    tense: resolved.tense,
    person: resolved.person || null,
    type: resolved.type,
    regular: resolved.regular,
    isParticiple: resolved.isParticiple || false
  };
}

// Get detailed conjugation info (including person/number)
export function getDetailedConjugationInfo(form) {
  const info = getGrammaticalFeatures(form);
  if (!info) return null;

  const personMap = {
    1: "first",
    2: "second",
    3: "third"
  };

  const numberMap = {
    1: "singular",
    2: "singular", // tú
    3: "singular", // él/ella/usted
    4: "plural", // nosotros
    5: "plural", // vosotros
    6: "plural" // ellos/ellas/ustedes
  };

  return {
    ...info,
    personName: info.person ? personMap[info.person] : null,
    number: info.person ? numberMap[info.person] : null,
    fullDescription: info.person 
      ? `${info.base} (${info.tense}, ${personMap[info.person]} person ${numberMap[info.person]})`
      : `${info.base} (${info.tense})`
  };
}