// src/engine/tutorEngine.js
import { loadStudent, saveStudent, updateStudent, markWordKnown, markWordWeak, recordMistake, updateAccuracy, addXP, checkLevelUp, isWordKnown } from "./studentModel";
import { getLanguageEngine } from "./databaseLoader";
import { analyze } from "./languageEngine";
import { correctSentence } from "./grammar";
import { generateResponse } from "./conversationGenerator";

export class TutorEngine {
  constructor() {
    this.student = loadStudent();
    this.languageEngine = getLanguageEngine();
    this.conversationContext = [];
    this.maxHistory = 50;
  }

  // ============================================================
  // PROCESS A USER INPUT
  // ============================================================

  processInput(input) {
    const analysis = analyze(input);
    const correction = correctSentence(input);
    
    // Track mistakes
    if (correction.reasons && correction.reasons.length > 0) {
      this.trackMistakes(correction);
    } else {
      this.student = updateAccuracy(this.student, true);
      // Mark words as known if used correctly
      this.trackVocabulary(analysis);
    }

    // Generate response
    const response = this.generateResponse(input, analysis);
    
    // Update conversation history
    this.conversationContext.push({
      user: input,
      tutor: response,
      timestamp: Date.now(),
      analysis,
      correction
    });

    if (this.conversationContext.length > this.maxHistory) {
      this.conversationContext.shift();
    }

    // Check for achievements
    this.checkAchievements();

    // Persist progress
    saveStudent(this.student);

    return {
      response,
      correction,
      analysis,
      student: this.getStudentSnapshot()
    };
  }

  // ============================================================
  // TRACK MISTAKES
  // ============================================================

  trackMistakes(correction) {
    correction.reasons.forEach(reason => {
      if (reason.includes("accent") || reason.includes("tild")) {
        this.student = recordMistake(this.student, "accents", "accents");
      } else if (reason.includes("verb") || reason.includes("conjug")) {
        this.student = recordMistake(this.student, "verbs", reason.match(/\b(\w+)\b/)?.[0] || "unknown");
      } else if (reason.includes("gender")) {
        this.student = recordMistake(this.student, "gender", "gender");
      } else if (reason.includes("punctuation")) {
        this.student = recordMistake(this.student, "punctuation", "punctuation");
      } else if (reason.includes("ser") || reason.includes("estar")) {
        this.student = recordMistake(this.student, "serEstar", "serEstar");
      } else if (reason.includes("preposition")) {
        this.student = recordMistake(this.student, "prepositions", "preposition");
      } else {
        this.student = recordMistake(this.student, "vocabulary", reason.match(/\b(\w+)\b/)?.[0] || "unknown");
      }
    });
    
    // Reduce accuracy for mistakes
    this.student = updateAccuracy(this.student, false);
  }

  // ============================================================
  // TRACK VOCABULARY
  // ============================================================

  trackVocabulary(analysis) {
    const words = analysis.tokens
      .filter(t => t.type === "word")
      .map(t => t.text);
    
    words.forEach(word => {
      if (!isWordKnown(this.student, word)) {
        this.student = markWordKnown(this.student, word);
        this.student = addXP(this.student, 2);
      }
    });
  }

  // ============================================================
  // GENERATE RESPONSE
  // ============================================================

  generateResponse(input, analysis) {
    const level = this.student.level;
    
    // Check if the input is a question
    if (analysis.isQuestion) {
      return this.generateQuestionResponse(input, analysis);
    }
    
    // Check if we can extract named entities
    const entities = this.extractEntities(analysis);
    if (entities.name) {
      return this.generatePersonalizedResponse(entities);
    }
    
    // Fallback: generate a level-appropriate response
    return this.generateLevelResponse(input, level);
  }

  // ============================================================
  // EXTRACT ENTITIES
  // ============================================================

  extractEntities(analysis) {
    const entities = {
      name: null,
      age: null,
      country: null,
      food: null,
      sport: null,
      color: null
    };
    
    // Extract name
    const nameMatch = analysis.original.match(/me llamo\s+(\w+)/i);
    if (nameMatch) entities.name = nameMatch[1];
    
    // Extract age
    const ageMatch = analysis.original.match(/tengo\s+(\d+)\s+años/i);
    if (ageMatch) entities.age = parseInt(ageMatch[1]);
    
    // Extract food
    if (analysis.entities?.foods?.length > 0) {
      entities.food = analysis.entities.foods[0];
    }
    
    // Extract sport
    if (analysis.entities?.sports?.length > 0) {
      entities.sport = analysis.entities.sports[0];
    }
    
    // Extract color
    if (analysis.entities?.colors?.length > 0) {
      entities.color = analysis.entities.colors[0];
    }
    
    return entities;
  }

  // ============================================================
  // RESPONSE GENERATORS
  // ============================================================

  generateQuestionResponse(input, analysis) {
    const level = this.student.level;
    
    if (level === "A1") {
      return this.getA1Response(input, analysis);
    } else if (level === "A2") {
      return this.getA2Response(input, analysis);
    } else if (level === "B1") {
      return this.getB1Response(input, analysis);
    } else {
      return this.getB2Response(input, analysis);
    }
  }

  getA1Response(input, analysis) {
    const responses = [
      "¡Qué bien!",
      "¡Interesante!",
      "¡Claro!",
      "¡Perfecto!",
      "¡Genial!"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  getA2Response(input, analysis) {
    const responses = [
      "¡Qué interesante! Cuéntame más.",
      "¿De verdad? No sabía eso.",
      "¡Qué bien! Sigue practicando.",
      "Muy bien. ¿Y qué más?",
      "¡Excelente! ¿Algo más?"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  getB1Response(input, analysis) {
    const responses = [
      "¡Qué fascinante! ¿Cómo fue esa experiencia?",
      "Entiendo perfectamente. ¿Y qué opinas de eso?",
      "¡Qué interesante! ¿Desde cuándo te gusta eso?",
      "Muy bien. ¿Puedes contarme más detalles?",
      "¡Qué buena idea! ¿Cómo se te ocurrió?"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  getB2Response(input, analysis) {
    const responses = [
      "¡Qué perspectiva tan interesante! ¿Qué te llevó a pensar así?",
      "Eso es algo que mucha gente no considera. ¿Cómo llegaste a esa conclusión?",
      "¡Qué fascinante! Me encantaría saber más sobre ese tema.",
      "Muy bien. ¿Has tenido experiencias similares antes?",
      "¡Qué buena observación! ¿Qué crees que significa eso?"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  generatePersonalizedResponse(entities) {
    if (entities.name) {
      return `¡Hola, ${entities.name}! ¿Cómo estás hoy?`;
    }
    if (entities.food) {
      return `¡Qué rico! ¿Te gusta cocinar ${entities.food}?`;
    }
    if (entities.sport) {
      return `¡Qué bien! ¿Juegas al ${entities.sport} frecuentemente?`;
    }
    return "¡Qué bien! Cuéntame más.";
  }

  generateLevelResponse(input, level) {
    if (level === "A1") {
      return "¡Cuéntame más!";
    } else if (level === "A2") {
      return "¡Qué interesante! ¿Y qué más?";
    } else if (level === "B1") {
      return "¡Qué bien! ¿Puedes darme más detalles?";
    } else {
      return "¡Excelente! ¿Cómo fue esa experiencia?";
    }
  }

  // ============================================================
  // STUDENT SNAPSHOT
  // ============================================================

  getStudentSnapshot() {
    return {
      level: this.student.level,
      xp: this.student.xp,
      streak: this.student.streak,
      accuracy: this.student.accuracy,
      knownWords: this.student.knownWords.length,
      weakWords: this.student.weakWords.length,
      mistakes: this.student.mistakes,
      achievements: this.student.achievements
    };
  }

  // ============================================================
  // ACHIEVEMENTS
  // ============================================================

  checkAchievements() {
    const achievements = [];
    
    if (this.student.xp >= 100 && !this.student.achievements.includes("first_100_xp")) {
      achievements.push("first_100_xp");
    }
    if (this.student.knownWords.length >= 50 && !this.student.achievements.includes("50_words")) {
      achievements.push("50_words");
    }
    if (this.student.streak >= 7 && !this.student.achievements.includes("7_day_streak")) {
      achievements.push("7_day_streak");
    }
    if (this.student.accuracy >= 90 && !this.student.achievements.includes("90_percent_accuracy")) {
      achievements.push("90_percent_accuracy");
    }
    
    if (achievements.length > 0) {
      this.student.achievements.push(...achievements);
      saveStudent(this.student);
    }
  }

  // ============================================================
  // CONVERSATION MEMORY
  // ============================================================

  getConversationMemory() {
    return this.conversationContext;
  }

  getLastConversation() {
    return this.conversationContext[this.conversationContext.length - 1];
  }

  // ============================================================
  // PERSONALIZED LESSON
  // ============================================================

  generatePersonalizedLesson() {
    const mistakes = this.student.mistakes;
    const totalMistakes = Object.values(mistakes).reduce(
      (sum, category) => sum + Object.values(category).reduce((a, b) => a + b, 0),
      0
    );
    
    // Find the top 3 mistake categories
    const categories = Object.entries(mistakes).map(([category, data]) => {
      const count = Object.values(data).reduce((a, b) => a + b, 0);
      return { category, count };
    });
    
    categories.sort((a, b) => b.count - a.count);
    const topCategories = categories.slice(0, 3);
    
    return {
      date: new Date().toISOString(),
      level: this.student.level,
      totalMistakes,
      accuracy: this.student.accuracy,
      knownWords: this.student.knownWords.length,
      weakWords: this.student.weakWords.length,
      focusAreas: topCategories.map(c => ({
        category: c.category,
        count: c.count,
        difficulty: c.count > 20 ? 5 : c.count > 10 ? 4 : c.count > 5 ? 3 : 2
      })),
      suggestedExercises: topCategories.map(c => ({
        category: c.category,
        exercises: this.generateExercises(c.category, 5)
      }))
    };
  }

  generateExercises(category, count = 5) {
    const exercises = {
      accents: [
        { question: "¿Cómo ___ (estas/estás)?", answer: "estás" },
        { question: "___ (Que/Qué) quieres?", answer: "Qué" },
        { question: "___ (Donde/Dónde) está el baño?", answer: "Dónde" }
      ],
      verbs: [
        { question: "Yo ___ (comer) pizza.", answer: "como" },
        { question: "Tú ___ (hablar) español.", answer: "hablas" },
        { question: "Ellos ___ (vivir) en Madrid.", answer: "viven" }
      ],
      gender: [
        { question: "La niña es ___ (bonito/bonita).", answer: "bonita" },
        { question: "El niño es ___ (alto/alta).", answer: "alto" },
        { question: "Las casas son ___ (blanco/blancas).", answer: "blancas" }
      ],
      serEstar: [
        { question: "Yo ___ de España.", answer: "soy" },
        { question: "Mi casa ___ en Madrid.", answer: "está" },
        { question: "Ella ___ cansada.", answer: "está" }
      ]
    };
    
    return (exercises[category] || []).slice(0, count);
  }
}

// Singleton instance
let tutorEngine = null;

export function getTutorEngine() {
  if (!tutorEngine) {
    tutorEngine = new TutorEngine();
  }
  return tutorEngine;
}