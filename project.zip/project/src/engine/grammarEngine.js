// src/engine/grammarEngine.js
import { subjects } from "../data/subjects";
import { adjectivePairs } from "../data/adjectives";
import { detectGender, detectNumber } from "./genderNumber";

// ============================================================
// GRAMMAR ANALYSIS
// ============================================================

export function analyzeGrammar(tokens) {
  const grammar = {
    subject: null,
    verb: null,
    tense: null,
    agreement: true,
    issues: [],
    gender: null,
    number: null,
    person: null,
    hasContraction: false,
    contractionIssues: []
  };

  for (const token of tokens) {
    if (token.type === "subject") {
      grammar.subject = token;
      const subjData = subjects[token.text];
      if (subjData) {
        grammar.person = subjData.person;
        grammar.number = subjData.number;
      }
    }
    
    if (token.type === "verb") {
      grammar.verb = token;
      grammar.tense = token.tense || "unknown";
      
      // Check if verb has person/number info
      if (token.person) {
        grammar.person = token.person;
        grammar.number = token.number || "singular";
      }
    }
  }

  // Check agreement between subject and verb
  if (grammar.subject && grammar.verb) {
    const agreement = checkAgreement(grammar.subject, grammar.verb);
    if (agreement && agreement.error) {
      grammar.agreement = false;
      grammar.issues.push(agreement);
    }
  }

  return grammar;
}

// ============================================================
// SUBJECT-VERB AGREEMENT
// ============================================================

export function checkAgreement(subject, verb) {
  if (!subject || !verb) return null;
  
  const subjData = subjects[subject.text];
  if (!subjData) return null;

  // If verb has person info, check against subject
  if (verb.person !== undefined) {
    if (subjData.person !== verb.person) {
      return {
        error: true,
        reason: `Person mismatch: Subject "${subject.text}" (${subjData.person}st/nd/rd person) does not match verb "${verb.base}" (${verb.person}st/nd/rd person).`,
        expected: {
          person: subjData.person,
          number: subjData.number
        }
      };
    }
  }

  return { error: false };
}

// ============================================================
// GENDER & NUMBER ANALYSIS
// ============================================================

export function analyzeGenderNumber(tokens) {
  const result = {
    gender: "unknown",
    number: "singular",
    issues: []
  };

  const nouns = tokens.filter(t => t.type === "noun");
  const adjectives = tokens.filter(t => t.type === "adjective");

  // Check each noun-adjective pair
  for (const noun of nouns) {
    const nounGender = detectGender(noun.text);
    const nounNumber = detectNumber(noun.text);
    
    // Find adjectives that might modify this noun
    const nearbyAdjectives = adjectives.filter(adj => {
      const adjPos = tokens.indexOf(adj);
      const nounPos = tokens.indexOf(noun);
      return Math.abs(adjPos - nounPos) < 3; // Within 3 positions
    });

    for (const adj of nearbyAdjectives) {
      const adjGender = detectGender(adj.text);
      const adjNumber = detectNumber(adj.text);

      if (nounGender !== adjGender && nounGender !== "unknown") {
        result.issues.push({
          error: true,
          reason: `Gender mismatch: "${noun.text}" (${nounGender}) vs "${adj.text}" (${adjGender})`,
          expected: {
            noun: noun.text,
            adjective: adj.text,
            correctAdjective: getCorrectForm(adj, nounGender, nounNumber)
          }
        });
      }

      if (nounNumber !== adjNumber) {
        result.issues.push({
          error: true,
          reason: `Number mismatch: "${noun.text}" (${nounNumber}) vs "${adj.text}" (${adjNumber})`,
          expected: {
            noun: noun.text,
            adjective: adj.text,
            correctAdjective: getCorrectForm(adj, nounGender, nounNumber)
          }
        });
      }
    }
  }

  return result;
}

// ============================================================
// CONTRACTION CHECK
// ============================================================

export function checkContractions(tokens) {
  const issues = [];
  
  for (let i = 0; i < tokens.length - 1; i++) {
    const current = tokens[i];
    const next = tokens[i + 1];
    
    // Check "a el" -> "al"
    if (current.text === "a" && next.text === "el") {
      issues.push({
        error: true,
        type: "contraction",
        original: "a el",
        corrected: "al",
        reason: '"a" + "el" must contract to "al".'
      });
    }
    
    // Check "de el" -> "del"
    if (current.text === "de" && next.text === "el") {
      issues.push({
        error: true,
        type: "contraction",
        original: "de el",
        corrected: "del",
        reason: '"de" + "el" must contract to "del".'
      });
    }
  }

  return issues;
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================

function getCorrectForm(adj, gender, number) {
  const base = adj.base || adj.text;
  const pairs = adjectivePairs[base];
  
  if (pairs) {
    const genderForm = gender === "feminine" ? pairs.feminine : pairs.masculine;
    return number === "plural" ? `${genderForm}s` : genderForm;
  }
  
  return adj.text; // No change if not in dictionary
}

// ============================================================
// FULL GRAMMAR ANALYSIS
// ============================================================

export function fullGrammarAnalysis(tokens) {
  const grammar = analyzeGrammar(tokens);
  const genderNumber = analyzeGenderNumber(tokens);
  const contractions = checkContractions(tokens);
  
  return {
    ...grammar,
    genderIssues: genderNumber.issues,
    contractionIssues: contractions,
    allIssues: [...grammar.issues, ...genderNumber.issues, ...contractions]
  };
}

// ============================================================
// GRAMMAR EXPLANATION
// ============================================================

export function generateGrammarExplanation(issues) {
  if (!issues || issues.length === 0) {
    return "✅ No grammar issues detected. ¡Perfecto!";
  }

  const lines = ["🔴 Grammar Issues Found:"];
  
  issues.forEach((issue, index) => {
    lines.push(`  ${index + 1}. ${issue.reason}`);
    if (issue.expected && issue.expected.correctAdjective) {
      lines.push(`     → Try: "${issue.expected.correctAdjective}"`);
    }
    if (issue.corrected) {
      lines.push(`     → Use: "${issue.corrected}"`);
    }
  });

  return lines.join("\n");
}

// ============================================================
// SINGLETON ACCESSOR (used by the engine manifest)
// ============================================================

let grammarEngineInstance = null;

export function getGrammarEngine() {
  if (!grammarEngineInstance) {
    grammarEngineInstance = {
      analyzeGrammar,
      checkAgreement,
      analyzeGenderNumber,
      checkContractions,
      fullGrammarAnalysis,
      generateGrammarExplanation
    };
  }
  return grammarEngineInstance;
}
