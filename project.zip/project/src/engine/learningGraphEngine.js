// src/engine/learningGraphEngine.js
import { LEARNING_GRAPH, getNode, getRelatedNodes, getRecommendedNext, getLearningPath } from "../data/learningGraph";
import { loadStudent, markWordKnown } from "./studentModel";

export class LearningGraphEngine {
  constructor() {
    this.graph = LEARNING_GRAPH;
    this.student = loadStudent();
  }

  // ============================================================
  // GET RECOMMENDATIONS
  // ============================================================

  getRecommendations(currentWord = null) {
    const knownWords = Array.from(this.student.knownWords || []);
    
    // If a current word is provided, get recommendations from it
    if (currentWord) {
      return getRecommendedNext(currentWord, knownWords);
    }
    
    // Otherwise, find the most connected unknown words
    const allWords = Object.keys(this.graph);
    const unknown = allWords.filter(w => !knownWords.includes(w));
    
    // Score each unknown word by how many known words it connects to
    const scored = unknown.map(id => {
      const connections = this.graph[id]?.connectsTo || [];
      const knownConnections = connections.filter(c => knownWords.includes(c));
      return { id, score: knownConnections.length };
    });
    
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, 10).map(item => this.graph[item.id]).filter(Boolean);
  }

  // ============================================================
  // BUILD LEARNING PATH
  // ============================================================

  buildLearningPath(targetWord) {
    const knownWords = Array.from(this.student.knownWords || []);
    return getLearningPath(targetWord, knownWords);
  }

  // ============================================================
  // GET RELATED WORDS
  // ============================================================

  getRelatedWords(word, maxDepth = 2) {
    return getRelatedNodes(word, maxDepth);
  }

  // ============================================================
  // GENERATE LESSON FROM GRAPH
  // ============================================================

  generateGraphLesson(topic) {
    const topicNode = this.graph[topic];
    if (!topicNode) return null;
    
    const connections = topicNode.connectsTo || [];
    const related = connections
      .map(id => this.graph[id])
      .filter(Boolean);
    
    // Build a lesson around this topic and its connections
    return {
      topic: topicNode.label,
      coreWord: topic,
      relatedWords: related.map(r => r.label),
      connections: connections,
      difficulty: topicNode.difficulty,
      category: topicNode.category
    };
  }

  // ============================================================
  // UPDATE STUDENT KNOWLEDGE
  // ============================================================

  markWordAsKnown(word) {
    this.student = markWordKnown(this.student, word);
    return this.student;
  }

  // ============================================================
  // GET LEARNING STATS
  // ============================================================

  getLearningStats() {
    const knownWords = Array.from(this.student.knownWords || []);
    const totalWords = Object.keys(this.graph).length;
    
    // Build a map of known vs unknown by category
    const categories = {};
    for (const [id, node] of Object.entries(this.graph)) {
      const cat = node.category || "uncategorized";
      if (!categories[cat]) {
        categories[cat] = { total: 0, known: 0 };
      }
      categories[cat].total++;
      if (knownWords.includes(id)) {
        categories[cat].known++;
      }
    }
    
    // Find the next logical words to learn
    const recommendations = this.getRecommendations();
    
    return {
      totalWords,
      knownWords: knownWords.length,
      progress: Math.round((knownWords.length / totalWords) * 100),
      categories,
      recommendations
    };
  }

  // ============================================================
  // GRAPH VISUALIZATION (for debugging)
  // ============================================================

  getGraphForWord(word, depth = 2) {
    const result = {
      center: word,
      nodes: [word],
      edges: []
    };
    
    const visited = new Set([word]);
    const queue = [{ id: word, depth: 0 }];
    
    while (queue.length > 0) {
      const { id, depth } = queue.shift();
      if (depth >= depth) continue;
      
      const connections = this.graph[id]?.connectsTo || [];
      for (const conn of connections) {
        if (!visited.has(conn)) {
          visited.add(conn);
          result.nodes.push(conn);
          result.edges.push({ from: id, to: conn });
          queue.push({ id: conn, depth: depth + 1 });
        }
      }
    }
    
    return result;
  }
}

// Singleton
let graphEngine = null;

export function getLearningGraphEngine() {
  if (!graphEngine) {
    graphEngine = new LearningGraphEngine();
  }
  return graphEngine;
}