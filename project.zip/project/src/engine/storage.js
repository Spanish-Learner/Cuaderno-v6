// src/engine/storage.js
const STORAGE_KEY = "cuaderno-spanish-v6";

const DEFAULT_STATE = {
  activeTab: "home",
  chatHistory: [],
  translatorHistory: [],
  corrections: [],
  learnedWords: {},
  progress: {},
  settings: {},
  conversationContext: {
    topic: "",
    lastQuestion: "",
    lastBotReply: "",
    memory: []
  }
};

export function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_STATE;
    return { ...DEFAULT_STATE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_STATE;
  }
}

export function saveState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function clearState() {
  localStorage.removeItem(STORAGE_KEY);
}