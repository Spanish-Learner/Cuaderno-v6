// src/engine/languageEngine.js
import { parseSentence } from "./parser";
import { detectTime, detectFormality, detectEmotion } from "./contextAnalyzer";
import { detectEntities } from "./entities";
import { resolveConjugation } from "./conjugationResolver";

// ============================================================
// MAIN ANALYSIS FUNCTION
// ============================================================

export function analyze(sentence) {
  // Parse the sentence into tokens
  const tokens = parseSentence(sentence);
  
  // Detect context
  const tense = detectTime(tokens.tokens || tokens);
  const formality = detectFormality(tokens.tokens || tokens);
  const emotion = detectEmotion(tokens.tokens || tokens);
  
  // Detect entities
  const entities = detectEntities(tokens.tokens || tokens);
  
  // Extract verbs and words
  const verbs = (tokens.tokens || tokens).filter(t => t.type === "verb");
  const words = (tokens.tokens || tokens).filter(t => t.type === "word");
  
  // Find the main verb (first verb in sentence)
  const mainVerb = verbs.length > 0 ? verbs[0] : null;
  
  // Build analysis result
  return {
    original: sentence,
    tokens: tokens.tokens || tokens,
    structure: tokens.structure || null,
    tense,
    formality,
    emotion,
    entities,
    verbs,
    words,
    mainVerb,
    hasVerb: verbs.length > 0,
    hasSubject: !!(tokens.structure?.subject),
    wordCount: (tokens.tokens || tokens).length,
    isQuestion: !!(tokens.structure?.question),
    isExclamation: !!(tokens.structure?.exclamation),
    
    // Helper methods
    getVerb: () => mainVerb,
    getSubject: () => tokens.structure?.subject,
    getObjects: () => tokens.structure?.objects || [],
    getTimeMarker: () => tokens.structure?.timeMarker || null,
    getPrepositions: () => tokens.structure?.prepositions || []
  };
}

// ============================================================
// QUICK ANALYSIS
// ============================================================

export function quickAnalyze(sentence) {
  const tokens = parseSentence(sentence);
  const verbs = (tokens.tokens || tokens).filter(t => t.type === "verb");
  const firstVerb = verbs.length > 0 ? verbs[0] : null;
  
  return {
    hasVerb: verbs.length > 0,
    mainVerb: firstVerb,
    verbCount: verbs.length,
    wordCount: (tokens.tokens || tokens).length,
    isQuestion: !!(tokens.structure?.question),
    isExclamation: !!(tokens.structure?.exclamation)
  };
}

// ============================================================
// VOCABULARY EXTRACTION
// ============================================================

export function contains(sentence, word) {
  const analysis = analyze(sentence);
  const allWords = analysis.tokens
    .filter(t => t.type === "word")
    .map(t => t.text);
  const allVerbs = analysis.tokens
    .filter(t => t.type === "verb")
    .map(t => t.base);
  
  return allWords.includes(word) || allVerbs.includes(word);
}

export function extractVocabulary(sentence) {
  const analysis = analyze(sentence);
  const words = new Set();
  const verbs = new Set();
  
  analysis.tokens.forEach(t => {
    if (t.type === "word") words.add(t.text);
    if (t.type === "verb") verbs.add(t.base);
  });
  
  return {
    words: Array.from(words),
    verbs: Array.from(verbs)
  };
}

// ============================================================
// WORD LOOKUP
// ============================================================

export function lookupWord(word, dictionary) {
  if (!dictionary) return null;
  const entry = dictionary.find(item =>
    item.es && item.es.toLowerCase() === word.toLowerCase()
  );
  return entry || null;
}

// ============================================================
// SENTENCE METADATA
// ============================================================

export function getSentenceMetadata(sentence) {
  const analysis = analyze(sentence);
  return {
    length: analysis.wordCount,
    hasVerb: analysis.hasVerb,
    hasSubject: analysis.hasSubject,
    isQuestion: analysis.isQuestion,
    tense: analysis.tense,
    entities: analysis.entities,
    complexity: analysis.wordCount > 10 ? "complex" : analysis.wordCount > 5 ? "medium" : "simple"
  };
}