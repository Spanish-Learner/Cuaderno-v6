// src/engine/flashcardEngine.js

// === Core Types ===
// mastery: 0-100 (0=new, 100=mastered)
// ease: 1.3-2.5 (SM-2 ease factor)
// interval: days between reviews
// nextReview: timestamp

// === SM-2 Algorithm ===
export function calculateNextReview(card, quality) {
  // quality: 0=again, 1=hard, 2=good, 3=easy, 4=very easy
  const now = Date.now();
  let ease = card.ease || 2.5;
  let interval = card.interval || 0;
  let mastery = card.mastery || 0;

  // Quality 0 = Again (reset)
  if (quality === 0) {
    interval = 0;
    ease = Math.max(1.3, ease - 0.2);
    mastery = Math.max(0, mastery - 20);
  }
  // Quality 1 = Hard
  else if (quality === 1) {
    interval = Math.max(1, interval * 1.2);
    ease = Math.max(1.3, ease - 0.15);
    mastery = Math.max(0, mastery - 10);
  }
  // Quality 2 = Good
  else if (quality === 2) {
    if (interval === 0) interval = 1;
    else if (interval === 1) interval = 6;
    else interval = Math.round(interval * ease);
    ease = Math.min(2.5, ease + 0.1);
    mastery = Math.min(100, mastery + 5);
  }
  // Quality 3 = Easy
  else if (quality === 3) {
    if (interval === 0) interval = 2;
    else if (interval === 1) interval = 12;
    else interval = Math.round(interval * ease * 1.3);
    ease = Math.min(2.5, ease + 0.15);
    mastery = Math.min(100, mastery + 10);
  }
  // Quality 4 = Very Easy
  else {
    if (interval === 0) interval = 4;
    else if (interval === 1) interval = 24;
    else interval = Math.round(interval * ease * 1.5);
    ease = Math.min(2.5, ease + 0.2);
    mastery = Math.min(100, mastery + 15);
  }

  const nextReview = now + interval * 24 * 60 * 60 * 1000;

  return {
    interval,
    ease,
    mastery,
    nextReview,
    lastReviewed: now,
    reviewCount: (card.reviewCount || 0) + 1,
    timesCorrect: quality >= 2 ? (card.timesCorrect || 0) + 1 : card.timesCorrect || 0,
    timesWrong: quality < 2 ? (card.timesWrong || 0) + 1 : card.timesWrong || 0,
    streak: quality >= 2 ? (card.streak || 0) + 1 : 0,
    maxStreak: Math.max(card.maxStreak || 0, quality >= 2 ? (card.streak || 0) + 1 : 0)
  };
}

// === Smart Deck Manager ===
export function getDeckStats(cards) {
  const now = Date.now();
  const total = cards.length;
  const mastered = cards.filter(c => c.mastery >= 80).length;
  const learning = cards.filter(c => c.mastery >= 20 && c.mastery < 80).length;
  const newCards = cards.filter(c => c.mastery === 0 && !c.nextReview).length;
  const dueToday = cards.filter(c => 
    c.nextReview && c.nextReview < now && c.mastery < 80
  ).length;
  const weakWords = cards.filter(c => 
    c.mastery < 40 && c.timesWrong > c.timesCorrect
  ).length;
  const favorites = cards.filter(c => c.favorite).length;

  return { total, mastered, learning, new: newCards, dueToday, weakWords, favorites };
}

// === Smart Shuffle ===
export function getBalancedStudyOrder(cards, count = 20) {
  const now = Date.now();
  
  // Due cards (need review)
  const due = cards.filter(c => 
    c.nextReview && c.nextReview < now && c.mastery < 80
  );
  
  // New cards (never reviewed)
  const newCards = cards.filter(c => c.mastery === 0 && !c.nextReview);
  
  // Weak cards (low mastery, high wrong rate)
  const weak = cards.filter(c => 
    c.mastery < 50 && c.timesWrong > c.timesCorrect && c.mastery > 0
  ).sort((a, b) => a.mastery - b.mastery);

  // Balanced mix: 50% due, 25% new, 25% weak
  const dueCount = Math.min(Math.floor(count * 0.5), due.length);
  const newCount = Math.min(Math.floor(count * 0.25), newCards.length);
  const weakCount = Math.min(Math.floor(count * 0.25), weak.length);

  // Randomize within each group
  const shuffledDue = shuffleArray(due).slice(0, dueCount);
  const shuffledNew = shuffleArray(newCards).slice(0, newCount);
  const shuffledWeak = shuffleArray(weak).slice(0, weakCount);

  // Combine and shuffle final order
  const selected = shuffleArray([...shuffledDue, ...shuffledNew, ...shuffledWeak]);
  
  return selected;
}

// === Confusion Pairs ===
export function detectConfusionPairs(cards, threshold = 3) {
  // Find cards where the user has wrong answers
  const problemCards = cards.filter(c => 
    c.timesWrong >= threshold && c.timesWrong > c.timesCorrect * 0.5
  );

  if (problemCards.length < 2) return [];

  // Group by similar tags/categories
  const groups = {};
  problemCards.forEach(c => {
    const key = c.tags?.join(',') || 'unknown';
    if (!groups[key]) groups[key] = [];
    groups[key].push(c);
  });

  // Return pairs from the same category
  const pairs = [];
  Object.values(groups).forEach(group => {
    for (let i = 0; i < group.length - 1; i++) {
      for (let j = i + 1; j < group.length; j++) {
        pairs.push([group[i], group[j]]);
      }
    }
  });

  return pairs;
}

// === Similar Word Trainer ===
export function findRelatedWords(card, allCards, limit = 4) {
  // Find cards with similar tags
  const related = allCards.filter(c => 
    c.id !== card.id && 
    c.tags?.some(tag => card.tags?.includes(tag))
  );

  // Sort by how related (same category first)
  return related.slice(0, limit);
}

// === Helper Functions ===
function shuffleArray(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// === Quiz Generator ===
export function generateQuiz(cards, count = 5) {
  const selected = shuffleArray(cards).slice(0, count);
  return selected.map(card => {
    // Create 3 wrong options from other cards
    const wrongOptions = shuffleArray(cards.filter(c => c.id !== card.id))
      .slice(0, 3)
      .map(c => c.back);
    
    // Shuffle all options
    const options = shuffleArray([card.back, ...wrongOptions]);
    
    return {
      question: card.front,
      answer: card.back,
      options,
      cardId: card.id
    };
  });
}