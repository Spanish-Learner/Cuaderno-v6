// src/engine/sentenceParser.js
import { resolveConjugation, isConjugatedForm } from "./conjugationResolver";

// ============================================================
// TENSE DETECTION
// ============================================================

export function detectTense(form) {
  const lower = form.toLowerCase();

  // Conditional markers — checked BEFORE imperfect. Conditional is the full
  // infinitive (which already ends in ar/er/ir) + ía/ías/etc, e.g. "hablar" + "ía"
  // = "hablaría". Imperfect is the stem (infinitive minus ar/er/ir) + ía, e.g.
  // "com" + "ía" = "comía". Both end in plain "ía$", so checking the longer,
  // distinctive "-aría/-ería/-iría" pattern first is what tells them apart.
  if (lower.match(/(aría|ería|iría|arías|erías|irías|aríamos|eríamos|iríamos|aríais|eríais|iríais|arían|erían|irían)$/)) {
    return "conditional";
  }

  // Future markers — checked BEFORE preterite, same reasoning: future keeps the
  // full infinitive ("hablar" + "é" = "hablaré"), preterite uses just the stem
  // ("habl" + "é" = "hablé"). Both end in plain "é$", so check the distinctive
  // "-aré/-eré/-iré" pattern first.
  if (lower.match(/(aré|eré|iré|arás|erás|irás|ará|erá|irá|aremos|eremos|iremos|aréis|eréis|iréis|arán|erán|irán)$/)) {
    return "future";
  }

  // Preterite markers
  if (lower.match(/(é|í|iste|ió|imos|isteis|ieron)$/)) return "preterite";

  // Imperfect markers
  if (lower.match(/(aba|abas|ábamos|abais|aban|ía|ías|íamos|íais|ían)$/)) return "imperfect";

  // Present (default)
  return "present";
}

// ============================================================
// PERSON DETECTION
// ============================================================

export function detectPerson(form) {
  const lower = form.toLowerCase();

  // Plural forms checked first (more specific, multi-letter endings)
  if (lower.match(/(amos|emos|imos|ábamos|íamos|aríamos|eríamos|iríamos|aremos|eremos|iremos)$/)) return 4; // first plural
  if (lower.match(/(áis|éis|ís|asteis|isteis|abais|íais|aríais|eríais|iríais|aréis|eréis|iréis)$/)) return 5; // second plural (vosotros)
  if (lower.match(/(an|en|on|aron|ieron|aban|ían|arían|erían|irían|arán|erán|irán)$/)) return 6; // third plural

  // Singular forms
  if (lower.match(/(o|é|í|aré|eré|iré)$/)) return 1; // first singular
  if (lower.match(/(as|es|iste|ás|arás|erás|irás|abas|ías|arías|erías|irías)$/)) return 2; // second singular
  if (lower.match(/(a|e|ió|á|ará|erá|irá|aba|ía|aría|ería|iría)$/)) return 3; // third singular

  return null; // unknown
}

// ============================================================
// SUBJECT PRONOUNS
// ============================================================

export const subjectPronouns = {
  "yo": { person: 1, number: "singular" },
  "tú": { person: 2, number: "singular" },
  "él": { person: 3, number: "singular" },
  "ella": { person: 3, number: "singular" },
  "usted": { person: 3, number: "singular" },
  "nosotros": { person: 1, number: "plural" },
  "nosotras": { person: 1, number: "plural" },
  "vosotros": { person: 2, number: "plural" },
  "vosotras": { person: 2, number: "plural" },
  "ellos": { person: 3, number: "plural" },
  "ellas": { person: 3, number: "plural" },
  "ustedes": { person: 3, number: "plural" }
};

// ============================================================
// SENTENCE PARSING
// ============================================================

export function parseSentence(sentence) {
  const words = sentence.toLowerCase().trim().split(/\s+/);
  const result = {
    subject: null,
    verb: null,
    verbForm: null,
    tense: null,
    person: null,
    number: null,
    objects: [],
    raw: sentence,
    tokens: words
  };

  // Find subject (if present)
  for (const word of words) {
    if (subjectPronouns[word]) {
      result.subject = word;
      result.person = subjectPronouns[word].person;
      result.number = subjectPronouns[word].number;
      break;
    }
  }

  // Find conjugated verb
  for (const word of words) {
    if (isConjugatedForm(word)) {
      const resolved = resolveConjugation(word);
      if (resolved) {
        result.verb = resolved.base;
        result.verbForm = word;
        result.tense = detectTense(word);
        // Only set person/number if not already set by subject
        if (!result.person) {
          result.person = detectPerson(word);
          const numberMap = {
            1: "singular", 2: "singular", 3: "singular",
            4: "plural", 5: "plural", 6: "plural"
          };
          result.number = numberMap[result.person] || "singular";
        }
        break;
      }
    }
  }

  // Collect objects (words after the verb)
  if (result.verbForm) {
    const verbIndex = words.indexOf(result.verbForm);
    if (verbIndex !== -1 && verbIndex < words.length - 1) {
      result.objects = words.slice(verbIndex + 1);
    }
  }

  return result;
}

// ============================================================
// ENGLISH GENERATION
// ============================================================

export function generateEnglishFromParse(parse) {
  const { subject, verb, verbForm, tense, objects } = parse;
  
  if (!verb) return null;

  // Subject mapping
  const subjectMap = {
    "yo": "I",
    "tú": "you",
    "él": "he",
    "ella": "she",
    "usted": "you",
    "nosotros": "we",
    "ellos": "they",
    "ellas": "they",
    "ustedes": "you"
  };

  // Get base verb in English (simplified mapping)
  const verbMap = {
    "comer": "eat",
    "hablar": "speak",
    "ir": "go",
    "ser": "be",
    "estar": "be",
    "tener": "have",
    "hacer": "do",
    "decir": "say",
    "poder": "can",
    "querer": "want",
    "saber": "know",
    "vivir": "live",
    "trabajar": "work",
    "estudiar": "study",
    "llegar": "arrive",
    "salir": "leave",
    "venir": "come",
    "dar": "give",
    "ver": "see",
    "entender": "understand",
    "necesitar": "need",
    "gustar": "like",
    "pensar": "think",
    "empezar": "start",
    "terminar": "finish",
    "abrir": "open",
    "cerrar": "close",
    "buscar": "look for",
    "encontrar": "find",
    "perder": "lose",
    "ganar": "win"
  };

  const baseVerb = verbMap[verb] || verb;
  const subjectEnglish = subject ? subjectMap[subject] || "I" : "I";

  // Tense mapping
  const tenseMap = {
    "present": baseVerb,
    "preterite": `${baseVerb}ed`,
    "imperfect": `was ${baseVerb}ing`,
    "future": `will ${baseVerb}`,
    "conditional": `would ${baseVerb}`
  };

  // Handle irregular past tense
  const irregularPast = {
    "go": "went",
    "be": "was/were",
    "have": "had",
    "do": "did",
    "make": "made",
    "say": "said",
    "can": "could",
    "want": "wanted",
    "know": "knew",
    "eat": "ate",
    "speak": "spoke",
    "see": "saw",
    "give": "gave",
    "come": "came",
    "leave": "left",
    "understand": "understood",
    "think": "thought",
    "write": "wrote",
    "read": "read"
  };

  let verbEnglish = tenseMap[tense] || baseVerb;
  if (tense === "preterite" && irregularPast[baseVerb]) {
    verbEnglish = irregularPast[baseVerb];
  }

  // Build sentence
  const objectEnglish = objects.length > 0 ? objects.join(" ") : "";
  
  let result = `${subjectEnglish} ${verbEnglish}`;
  if (objectEnglish) {
    result += ` ${objectEnglish}`;
  }

  return result;
}