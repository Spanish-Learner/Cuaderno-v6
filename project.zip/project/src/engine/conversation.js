// src/engine/conversation.js
const MEMORY_LIMIT = 15;

const greetings = [
  "¡Hola!",
  "¡Buenos días!",
  "¡Buenas tardes!",
  "¡Buenas noches!"
];

const followUps = {
  food: [
    "¿Cuál es tu comida favorita?",
    "¿Qué comiste hoy?",
    "¿Te gusta cocinar?"
  ],
  travel: [
    "¿Qué país te gustaría visitar?",
    "¿Has viajado antes?",
    "¿Cuál es tu ciudad favorita?"
  ],
  family: [
    "¿Tienes hermanos?",
    "¿Cómo se llama tu madre?",
    "¿Vives con tu familia?"
  ],
  school: [
    "¿Qué estudias?",
    "¿Cuál es tu materia favorita?",
    "¿Te gusta aprender español?"
  ],
  hobbies: [
    "¿Qué haces en tu tiempo libre?",
    "¿Practicas algún deporte?",
    "¿Te gusta leer?"
  ]
};

function detectTopic(text) {
  text = text.toLowerCase();
  if (text.includes("comida") || text.includes("pizza") || text.includes("hamburguesa")) return "food";
  if (text.includes("famil")) return "family";
  if (text.includes("escuela") || text.includes("universidad")) return "school";
  if (text.includes("viaj")) return "travel";
  if (text.includes("fútbol") || text.includes("videojuego") || text.includes("leer")) return "hobbies";
  return "";
}

export function createConversationMemory() {
  return {
    topic: "",
    history: [],
    lastBot: ""
  };
}

export function respond(message, memory) {
  const msg = message.trim();
  memory.history.push(msg);
  if (memory.history.length > MEMORY_LIMIT) memory.history.shift();

  const topic = detectTopic(msg);
  if (topic) memory.topic = topic;

  let reply = "";

  if (/^(hola|buenas|buenos días|buenas tardes)$/i.test(msg)) {
    reply = greetings[Math.floor(Math.random() * greetings.length)];
  } else if (/cómo estás/i.test(msg)) {
    reply = "Estoy muy bien. ¿Y tú?";
  } else if (memory.topic && followUps[memory.topic]) {
    const list = followUps[memory.topic];
    reply = list[Math.floor(Math.random() * list.length)];
  } else {
    reply = "Cuéntame más.";
  }

  memory.lastBot = reply;
  return { reply, memory };
}