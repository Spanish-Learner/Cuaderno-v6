// src/App.jsx
import React from "react";
import { AppProvider, useApp } from "./context/AppContext";

// Page Imports
import Home from "./components/Home";
import Students from "./pages/Students";
import Lessons from "./pages/Lessons";
import Practice from "./pages/Practice";
import Analytics from "./pages/Analytics";
import Settings from "./pages/Settings";

const APP_VERSION = "6.0.2";

export default function SpanishTutorApp() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

function AppContent() {
  const { state, booted, dispatch } = useApp();

  if (!booted || !state) {
    return (
      <div className="loading-screen">
        <div className="loading-spinner">🔄</div>
        <div className="loading-text">Loading Cuaderno...</div>
      </div>
    );
  }

  const TABS = [
    { id: "home", label: "Home", icon: "🏠" },
    { id: "students", label: "Students", icon: "👨‍🎓" },
    { id: "lessons", label: "Lessons", icon: "📚" },
    { id: "practice", label: "Practice", icon: "📝" },
    { id: "analytics", label: "Analytics", icon: "📊" },
    { id: "settings", label: "Settings", icon: "⚙️" }
  ];

  const activeIdx = TABS.findIndex((t) => t.id === state.ui?.activeTab || "home");

  return (
    <div className="app-root">
      <GlobalStyle />
      
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">ES</span>
          <div className="brand-text">
            <div className="brand-title">Cuaderno</div>
            <div className="brand-sub">Spanish Tutor · v{APP_VERSION}</div>
          </div>
        </div>
        <div className="stats">
          <div className="stamp">
            <div className="stamp-num">{state.student?.streak || 0}</div>
            <div className="stamp-label">day streak</div>
          </div>
          <div className="stamp teal">
            <div className="stamp-num">{state.student?.knownWords?.length || 0}</div>
            <div className="stamp-label">words learned</div>
          </div>
        </div>
      </header>

      <nav className="tabs">
        <div className="tab-indicator" style={{ transform: `translateX(${activeIdx * 100}%)`, width: `${100 / TABS.length}%` }} />
        {TABS.map((t) => (
          <button key={t.id} className={`tab-btn ${state.ui?.activeTab === t.id ? "active" : ""}`} onClick={() => dispatch({ type: 'SET_TAB', payload: t.id })}>
            <span className="tab-icon">{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </nav>

      <main className="content" key={state.ui?.activeTab}>
        {state.ui?.activeTab === "home" && <Home />}
        {state.ui?.activeTab === "students" && <Students />}
        {state.ui?.activeTab === "lessons" && <Lessons />}
        {state.ui?.activeTab === "practice" && <Practice />}
        {state.ui?.activeTab === "analytics" && <Analytics />}
        {state.ui?.activeTab === "settings" && <Settings />}
      </main>
    </div>
  );
}

// ============================================================
// GLOBAL STYLES (Combined Legacy + New UI)
// ============================================================

function GlobalStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap');

      :root {
        --ink: #0d121c;
        --ink-2: #171f2d;
        --ink-3: #1f2942;
        --paper: #f1e9d8;
        --paper-dim: #b6bdc9;
        --marigold: #e2a63b;
        --teal: #2b968f;
        --rose: #c25a72;
        --stamp: #b6432f;
        --line: rgba(241,233,216,0.12);
        --radius-sm: 8px;
        --radius-md: 12px;
        --radius-lg: 18px;
      }
      * { box-sizing: border-box; }
      .app-root {
        font-family: 'Inter', sans-serif;
        background:
          radial-gradient(circle at 3px 3px, rgba(241,233,216,0.05) 1px, transparent 0) 0 0/22px 22px,
          radial-gradient(ellipse at top, #17202f 0%, var(--ink) 60%);
        color: var(--paper);
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        max-width: 480px;
        margin: 0 auto;
        box-shadow: 0 20px 60px rgba(0,0,0,0.45);
        position: relative;
      }
      .loading-screen {
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        min-height: 100vh; color: var(--paper-dim); gap: 16px;
      }
      .loading-spinner { font-size: 32px; animation: spin 1s linear infinite; }
      @keyframes spin { 100% { transform: rotate(360deg); } }

      /* TOPBAR */
      .topbar {
        display: flex; align-items: center; justify-content: space-between;
        padding: 20px 20px 16px; position: relative;
      }
      .topbar::after {
        content: ""; position: absolute; left: 0; right: 0; bottom: -1px; height: 1px;
        background: var(--line);
        -webkit-mask-image: radial-gradient(circle 3px, transparent 98%, #000 100%);
        mask-image: radial-gradient(circle 3px, transparent 98%, #000 100%);
        -webkit-mask-size: 14px 3px; mask-size: 14px 3px;
        -webkit-mask-repeat: repeat-x; mask-repeat: repeat-x;
      }
      .brand { display: flex; align-items: center; gap: 12px; }
      .brand-mark {
        font-family: 'Fraunces', serif; font-weight: 600; font-size: 14px;
        color: var(--ink);
        background: var(--marigold);
        width: 36px; height: 36px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        transform: rotate(-8deg);
        box-shadow: 0 3px 0 rgba(0,0,0,0.25), 0 4px 10px rgba(226,166,59,0.35);
      }
      .brand-title { font-family: 'Fraunces', serif; font-size: 19px; font-weight: 600; line-height: 1.1; letter-spacing: 0.01em; }
      .brand-sub { font-size: 10.5px; color: var(--paper-dim); letter-spacing: 0.07em; text-transform: uppercase; margin-top: 2px; }
      
      .stats { display: flex; gap: 10px; }
      .stamp {
        border: 1.5px dashed var(--marigold); border-radius: 10px;
        padding: 5px 11px; text-align: center; transform: rotate(-3deg);
        min-width: 56px; position: relative; color: var(--marigold);
        background: rgba(226,166,59,0.06);
      }
      .stamp.teal { border-color: var(--teal); color: var(--teal); transform: rotate(3deg); background: rgba(43,150,143,0.06); }
      .stamp-num { font-family: 'Fraunces', serif; font-size: 18px; font-weight: 600; color: var(--paper); }
      .stamp-label { font-size: 8.5px; text-transform: uppercase; letter-spacing: 0.06em; color: inherit; opacity: 0.9; }

      /* TABS */
      .tabs { display: flex; border-bottom: 1px solid var(--line); position: relative; background: rgba(0,0,0,0.12); }
      .tab-btn {
        flex: 1; background: none; border: none; color: var(--paper-dim);
        padding: 13px 4px 11px; font-size: 12px; font-weight: 500; cursor: pointer;
        display: flex; flex-direction: column; align-items: center; gap: 5px;
        border-bottom: 2px solid transparent; transition: color 0.15s;
        letter-spacing: 0.02em;
      }
      .tab-icon { font-size: 16px; transition: transform 0.2s ease-out; }
      .tab-btn.active { color: var(--marigold); }
      .tab-btn.active .tab-icon { transform: translateY(-1px); }
      .tab-indicator {
        position: absolute; bottom: -1px; left: 0; height: 2px; background: var(--marigold);
        transition: transform 0.3s cubic-bezier(0.65, 0, 0.35, 1);
        box-shadow: 0 0 8px rgba(226,166,59,0.6);
      }
      @keyframes contentIn {
        from { opacity: 0; transform: translateY(6px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .content { animation: contentIn 0.28s ease-out; padding: 18px 18px 26px; overflow-y: auto; flex: 1; }

      /* ============================================================
         NEW UI STYLES (Home, Pages, Flashcards, Settings)
         ============================================================ */

      /* Page Container */
      .page-container { padding: 8px 0; display: flex; flex-direction: column; gap: 20px; }
      .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
      .page-header h1 { font-family: 'Fraunces', serif; font-size: 24px; margin: 0; color: var(--paper); }

      /* Buttons */
      .btn-primary, .btn-secondary, .btn-danger {
        padding: 8px 16px; border: none; border-radius: var(--radius-sm);
        font-weight: 500; cursor: pointer; transition: all 0.15s;
      }
      .btn-primary { background: var(--marigold); color: var(--ink); }
      .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
      .btn-secondary { background: var(--ink-3); color: var(--paper); border: 1px solid var(--line); }
      .btn-danger { background: var(--rose); color: white; }

      /* Home Dashboard */
      .home-container { display: flex; flex-direction: column; gap: 24px; padding-bottom: 20px; }
      .home-header { display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 16px; border-bottom: 1px solid var(--line); }
      .greeting h1 { font-size: 24px; font-weight: 600; margin: 0 0 4px 0; color: var(--paper); }
      .date-time { display: flex; gap: 12px; font-size: 14px; color: var(--paper-dim); }
      .time { font-weight: 500; color: var(--marigold); }
      .system-status { display: flex; align-items: center; gap: 8px; background: var(--ink-2); padding: 6px 14px; border-radius: 20px; border: 1px solid var(--line); }
      .status-dot { font-size: 16px; }
      .status-label { font-size: 13px; font-weight: 500; color: var(--paper); }

      .home-section h2 { font-size: 16px; font-weight: 600; color: var(--paper-dim); margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.06em; }
      
      /* Quick Actions */
      .quick-actions-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 12px; }
      .action-card { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; background: var(--ink-2); border: 1px solid var(--line); border-radius: var(--radius-md); padding: 16px 8px; cursor: pointer; transition: all 0.15s; }
      .action-card:hover { border-color: var(--marigold); background: rgba(226,166,59,0.08); transform: translateY(-2px); }
      .action-card .icon { font-size: 24px; }
      .action-card .label { font-size: 12px; font-weight: 500; color: var(--paper-dim); }

      /* Overview */
      .overview-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(80px, 1fr)); gap: 12px; }
      .stat-card { background: var(--ink-2); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 12px 14px; text-align: center; }
      .stat-value { display: block; font-size: 24px; font-weight: 600; color: var(--paper); }
      .stat-label { display: block; font-size: 11px; color: var(--paper-dim); margin-top: 4px; }

      /* Session Card */
      .session-card { display: flex; justify-content: space-between; align-items: center; background: var(--ink-2); padding: 16px; border-radius: var(--radius-md); border: 1px solid var(--line); border-left: 4px solid var(--marigold); }
      .session-card.empty { border-left-color: var(--paper-dim); }
      .session-info { flex: 1; }
      .session-info h3 { margin: 0 0 4px 0; font-size: 16px; }
      .progress-bar { height: 6px; background: var(--ink-3); border-radius: 4px; margin: 8px 0; overflow: hidden; width: 100%; max-width: 200px; }
      .progress-fill { height: 100%; background: var(--teal); transition: width 0.3s ease; }
      .time-estimate { font-size: 12px; color: var(--paper-dim); margin-top: 4px; }

      /* Recent Activity */
      .activity-list { display: flex; flex-direction: column; gap: 8px; }
      .activity-item { display: flex; align-items: center; gap: 12px; background: var(--ink-2); padding: 10px 14px; border-radius: var(--radius-sm); border: 1px solid var(--line); }
      .activity-icon { font-size: 18px; }
      .activity-content { flex: 1; }
      .activity-text { font-size: 13px; color: var(--paper); }
      .activity-time { font-size: 11px; color: var(--paper-dim); }

      /* Settings */
      .settings-list { display: flex; flex-direction: column; gap: 16px; }
      .setting-item { display: flex; justify-content: space-between; align-items: center; padding: 16px; background: var(--ink-2); border-radius: var(--radius-sm); border: 1px solid var(--line); }
      .setting-info h3 { margin: 0 0 4px 0; font-size: 15px; }
      .setting-info p { margin: 0; font-size: 12px; color: var(--paper-dim); }
      .setting-input { background: var(--ink-3); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 6px 10px; color: var(--paper); width: 150px; font-size: 14px; }
      .setting-input:focus { outline: none; border-color: var(--marigold); }
      .setting-select { background: var(--ink-3); border: 1px solid var(--line); color: var(--paper); padding: 4px 8px; border-radius: var(--radius-sm); }

      /* Students */
      .students-grid { display: flex; flex-direction: column; gap: 12px; }
      .student-card { display: flex; align-items: center; gap: 16px; background: var(--ink-2); padding: 16px; border-radius: var(--radius-md); border: 1px solid var(--line); }
      .student-avatar { font-size: 32px; }
      .student-info { flex: 1; }
      .student-info h3 { margin: 0 0 4px 0; font-size: 16px; }

      /* Lessons */
      .active-lesson-container { margin-top: 10px; }
      .empty-state { text-align: center; color: var(--paper-dim); padding: 40px 0; }

      /* Practice */
      .practice-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
      .practice-card { background: var(--ink-2); padding: 20px; border-radius: var(--radius-md); border: 1px solid var(--line); text-align: center; cursor: pointer; transition: all 0.15s; }
      .practice-card:hover { border-color: var(--marigold); transform: translateY(-2px); }
      .practice-icon { font-size: 32px; margin-bottom: 8px; }
      .practice-card h3 { font-size: 16px; margin: 0 0 8px 0; }
      .practice-card p { font-size: 12px; color: var(--paper-dim); margin-bottom: 12px; }

      /* Analytics */
      .analytics-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
      .weak-areas-section { margin-top: 20px; }
      .weak-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--line); font-size: 13px; }
      .mistake-count { color: var(--rose); }

      /* Correction Panel */
      .correction-panel { background: rgba(194, 90, 114, 0.12); border: 1px solid rgba(194, 90, 114, 0.4); border-radius: var(--radius-md); padding: 14px 16px; margin-top: 12px; }
      .correction-panel h3 { color: var(--rose); font-size: 14px; margin: 0 0 8px 0; font-weight: 600; text-transform: uppercase; letter-spacing: 0.06em; }
      .correction-panel h4 { color: var(--rose); font-size: 12px; margin: 10px 0 6px 0; font-weight: 600; }
      .wrong { color: var(--rose); text-decoration: line-through; }
      .correct { color: var(--teal); font-weight: 600; }

      /* Lesson View */
      .lesson-view { background: var(--ink-2); border: 1px solid var(--line); border-radius: var(--radius-lg); padding: 20px; }
      .lesson-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid var(--line); padding-bottom: 12px; }
      .lesson-header h2 { font-family: 'Fraunces', serif; font-size: 20px; color: var(--paper); margin: 0; }
      .lesson-progress { font-size: 12px; color: var(--paper-dim); }
      .lesson-content { min-height: 120px; margin-bottom: 20px; }
      .example-card { background: var(--ink-3); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 16px; margin: 8px 0; }
      .example-es { font-size: 18px; font-weight: 600; color: var(--teal); }
      .example-en { font-size: 14px; color: var(--paper-dim); margin-top: 4px; }
      .explanation-content { line-height: 1.6; color: var(--paper-dim); white-space: pre-line; }
      .lesson-controls { display: flex; justify-content: space-between; gap: 12px; margin-top: 20px; border-top: 1px solid var(--line); padding-top: 16px; }
      .lesson-btn { background: var(--ink-3); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 10px 20px; cursor: pointer; font-size: 14px; color: var(--paper); transition: all 0.15s; }
      .lesson-btn:hover:not(:disabled) { border-color: var(--marigold); }
      .lesson-btn:disabled { opacity: 0.5; cursor: not-allowed; }

      /* Flashcards */
      .flashcards-tab { padding: 0; }
      .flashcard-view { display: flex; flex-direction: column; align-items: center; gap: 20px; padding: 20px 0; }
      .flashcard-card { width: 100%; max-width: 300px; height: 180px; background: var(--ink-2); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-direction: column; border: 1px solid var(--line); }
      .flashcard-front { font-size: 24px; font-weight: 600; color: var(--marigold); }
      .flashcard-back { font-size: 18px; color: var(--teal); }

      /* Scrollbar */
      ::-webkit-scrollbar { width: 6px; }
      ::-webkit-scrollbar-thumb { background: var(--line); border-radius: 3px; }
    `}</style>
  );
}